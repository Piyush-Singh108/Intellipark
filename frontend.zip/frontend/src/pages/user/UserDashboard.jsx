import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { getSlots, getNearestSlot } from '../../services/slotService';
import { getMyReservations, getActiveReservation } from '../../services/reservationService';
import StatCard from '../../components/admin/StatCard';
import StatusBadge from '../../components/common/StatusBadge';
import Loader from '../../components/common/Loader';
import { formatDateTime, formatMoney } from '../../utils/format';
import {
  Car,
  Layers,
  CheckCircle2,
  Clock,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  DoorOpen,
  CalendarCheck,
} from 'lucide-react';

export default function UserDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState({ total: 0, available: 0, occupied: 0, reserved: 0 });
  const [activeBooking, setActiveBooking] = useState(null);
  const [nearestSlot, setNearestSlot] = useState(null);
  const [recentBookings, setRecentBookings] = useState([]);

  const loadDashboardData = async () => {
    setLoading(true);
    setError('');
    try {
      const [allSlots, activeRes, myBookings, nearestRes] = await Promise.all([
        getSlots(),
        getActiveReservation().catch(() => ({ active_reservation: null })),
        getMyReservations().catch(() => []),
        getNearestSlot().catch(() => null),
      ]);

      const availableCount = allSlots.filter((s) => s.status === 'available').length;
      const occupiedCount = allSlots.filter((s) => s.status === 'occupied').length;
      const reservedCount = allSlots.filter((s) => s.status === 'reserved').length;

      setStats({
        total: allSlots.length,
        available: availableCount,
        occupied: occupiedCount,
        reserved: reservedCount,
      });

      setActiveBooking(activeRes?.active_reservation || null);
      setRecentBookings(myBookings.slice(0, 4));
      setNearestSlot(nearestRes?.recommended_slot || null);
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Failed to load driver dashboard.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  if (loading) return <Loader message="Connecting to facility sensors..." />;
  if (error) return <Loader error={error} />;

  return (
    <div>
      {/* Welcome Hero Banner */}
      <div className="dashboard-hero">
        <div className="hero-top">
          <div className="hero-title">
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.35rem' }}>
              <span className="badge available" style={{ fontSize: '0.75rem' }}>
                <ShieldCheck size={12} /> System Online
              </span>
              <span style={{ color: 'var(--slate-300)', fontSize: '0.8rem' }}>
                Vehicle: <strong>{user?.vehicle_number || 'Not Registered'}</strong>
              </span>
            </div>
            <h1>Welcome back, {user?.name || 'Driver'}</h1>
            <p>Real-time parking availability and smart reservation management.</p>
          </div>

          <div className="hero-actions">
            <Link to="/slots" className="btn primary lg">
              <Layers size={18} />
              <span>Find a Parking Bay</span>
            </Link>
            <Link to="/terminal" className="btn outline lg" style={{ color: '#fff', borderColor: 'rgba(255,255,255,0.3)' }}>
              <DoorOpen size={18} />
              <span>Barrier Gate Terminal</span>
            </Link>
          </div>
        </div>

        {/* Active Reservation Banner (if exists) */}
        {activeBooking ? (
          <div className="active-res-banner">
            <div className="active-res-info">
              <div className="active-slot-pill">{activeBooking.slot_number}</div>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.2rem' }}>
                  <span style={{ fontWeight: 700, fontSize: '0.95rem', color: '#fff' }}>
                    Active Reservation at {activeBooking.lot_name || 'Main Lot'}
                  </span>
                  <StatusBadge status={activeBooking.status} />
                  <StatusBadge status={activeBooking.payment_status} />
                </div>
                <div style={{ fontSize: '0.825rem', color: 'var(--slate-300)' }}>
                  Level {activeBooking.floor} &bull; Valid: {formatDateTime(activeBooking.start_time)} &rarr; {formatDateTime(activeBooking.end_time)}
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '0.6rem' }}>
              {activeBooking.payment_status !== 'paid' && (
                <button
                  className="btn primary sm"
                  onClick={() => navigate(`/pay/${activeBooking.reservation_id}`)}
                >
                  Pay Now ({formatMoney(activeBooking.amount)})
                </button>
              )}
              <Link to="/reservations" className="btn secondary sm">
                View Pass
              </Link>
            </div>
          </div>
        ) : (
          <div
            style={{
              background: 'rgba(255, 255, 255, 0.05)',
              border: '1px dashed rgba(255, 255, 255, 0.2)',
              borderRadius: 'var(--radius-md)',
              padding: '0.85rem 1.25rem',
              fontSize: '0.85rem',
              color: 'var(--slate-300)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              flexWrap: 'wrap',
              gap: '0.5rem',
            }}
          >
            <span>No active reservations currently in progress. Reserve a slot in advance for guaranteed parking.</span>
            <Link to="/slots" style={{ color: 'var(--blue-400)', fontWeight: 600, textDecoration: 'none' }}>
              Explore Available Bays &rarr;
            </Link>
          </div>
        )}
      </div>

      {/* Facility Overview Metric Cards */}
      <h2 style={{ marginBottom: '1rem' }}>Live Facility Availability</h2>
      <div className="stats-grid">
        <StatCard
          label="Total Parking Capacity"
          value={stats.total}
          sub="3 Levels Monitored"
          color="blue"
          icon={<Car size={18} />}
        />
        <StatCard
          label="Available Bays"
          value={stats.available}
          sub="Ready for Reservation"
          color="emerald"
          icon={<CheckCircle2 size={18} />}
        />
        <StatCard
          label="Occupied Bays"
          value={stats.occupied}
          sub="Currently Parked"
          color="rose"
          icon={<Car size={18} />}
        />
        <StatCard
          label="Reserved Bays"
          value={stats.reserved}
          sub="Awaiting Vehicle Arrival"
          color="amber"
          icon={<Clock size={18} />}
        />
      </div>

      {/* Recommended Nearest Slot Widget */}
      {nearestSlot && (
        <div className="recommend-card">
          <div>
            <div className="recommend-badge">
              <Sparkles size={12} />
              <span>Smart Nearest Slot Recommendation</span>
            </div>
            <h3 style={{ margin: '0.2rem 0' }}>
              Bay {nearestSlot.slot_number} on Level {nearestSlot.floor}
            </h3>
            <p style={{ margin: 0 }}>
              Located approximately <strong>{nearestSlot.distance_from_entrance || 10} meters</strong> from the main
              entrance. Hourly Rate: <strong>{formatMoney(nearestSlot.hourly_rate)}/hr</strong>.
            </p>
          </div>
          <button
            className="btn primary"
            onClick={() => navigate('/slots', { state: { selectSlotId: nearestSlot.slot_id } })}
          >
            <span>Reserve Recommended Bay</span>
            <ArrowRight size={15} />
          </button>
        </div>
      )}

      {/* Recent Reservations Table */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '2rem 0 1rem' }}>
        <h2>My Recent Parking Activity</h2>
        <Link to="/reservations" className="btn outline sm">
          <CalendarCheck size={14} />
          <span>View All Bookings</span>
        </Link>
      </div>

      {recentBookings.length === 0 ? (
        <div className="empty-state">
          <Car className="empty-icon" />
          <div className="empty-title">No bookings on record yet</div>
          <div className="empty-description">
            You haven't reserved any parking bays. Select an available bay from the live map to get started.
          </div>
          <Link to="/slots" className="btn primary">
            Find an Available Slot
          </Link>
        </div>
      ) : (
        <div className="table-card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Bay</th>
                  <th>Vehicle</th>
                  <th>Schedule</th>
                  <th>Amount</th>
                  <th>Reservation Status</th>
                  <th>Payment Status</th>
                  <th style={{ textAlign: 'right' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {recentBookings.map((r) => (
                  <tr key={r.reservation_id}>
                    <td>
                      <strong style={{ fontFamily: 'var(--font-mono)' }}>{r.slot_number}</strong>
                      <div style={{ fontSize: '0.75rem', color: 'var(--slate-400)' }}>Level {r.floor}</div>
                    </td>
                    <td>
                      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.85rem' }}>
                        {r.vehicle_number || user?.vehicle_number || 'N/A'}
                      </span>
                    </td>
                    <td>
                      <div style={{ fontSize: '0.825rem' }}>{formatDateTime(r.start_time)}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--slate-400)' }}>to {formatDateTime(r.end_time)}</div>
                    </td>
                    <td>
                      <strong>{formatMoney(r.amount)}</strong>
                    </td>
                    <td>
                      <StatusBadge status={r.status} />
                    </td>
                    <td>
                      <StatusBadge status={r.payment_status} />
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      {r.status === 'confirmed' && r.payment_status !== 'paid' ? (
                        <button
                          className="btn primary sm"
                          onClick={() => navigate(`/pay/${r.reservation_id}`)}
                        >
                          Pay
                        </button>
                      ) : (
                        <Link to="/reservations" className="btn outline sm">
                          Details
                        </Link>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
