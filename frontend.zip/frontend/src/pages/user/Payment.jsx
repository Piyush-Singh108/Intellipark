import { useState, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { getReservationById } from '../../services/reservationService';
import { makePayment } from '../../services/paymentService';
import StatusBadge from '../../components/common/StatusBadge';
import Loader from '../../components/common/Loader';
import { formatDateTime, formatMoney, formatDuration } from '../../utils/format';
import { PAYMENT_METHODS } from '../../utils/constants';
import {
  CreditCard,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  QrCode,
  ArrowRight,
  Printer,
  Car,
  Clock,
  Building,
} from 'lucide-react';

export default function Payment() {
  const { reservationId } = useParams();
  const navigate = useNavigate();

  const [reservation, setReservation] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Payment form state
  const [selectedMethod, setSelectedMethod] = useState('upi');
  const [upiId, setUpiId] = useState('driver@okhdfcbank');
  const [cardNumber, setCardNumber] = useState('4532 &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; 8921');
  const [cardExpiry, setCardExpiry] = useState('08/28');
  const [cardCvv, setCardCvv] = useState('883');
  const [submitting, setSubmitting] = useState(false);
  const [paymentSuccessData, setPaymentSuccessData] = useState(null);
  const [paymentError, setPaymentError] = useState('');

  // Fetch reservation details
  useEffect(() => {
    const fetchRes = async () => {
      setLoading(true);
      setError('');
      try {
        const data = await getReservationById(reservationId);
        setReservation(data);

        // If already paid, set payment success state directly
        if (data.payment_status === 'paid') {
          setPaymentSuccessData({
            transaction_id: data.transaction_id,
            amount: data.amount,
            method: data.payment_method || 'card',
            status: 'paid',
            gateway_provider: data.gateway_provider || 'IntelliPark Simulated Gateway',
          });
        }
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to load reservation details.');
      } finally {
        setLoading(false);
      }
    };

    fetchRes();
  }, [reservationId]);

  const handlePay = async (e) => {
    e.preventDefault();
    setPaymentError('');
    setSubmitting(true);

    try {
      const result = await makePayment({
        reservation_id: reservationId,
        method: selectedMethod,
        upi_id: selectedMethod === 'upi' ? upiId : undefined,
        card_details: selectedMethod === 'card' ? { last4: '8921' } : undefined,
      });

      setPaymentSuccessData(result);
    } catch (err) {
      setPaymentError(err.response?.data?.message || 'Payment processing failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <Loader message="Retrieving booking and tariff information..." />;
  if (error) return <Loader error={error} />;
  if (!reservation) return <div className="alert-banner critical">Reservation not found.</div>;

  // Render Payment Success / Digital Receipt State
  if (paymentSuccessData) {
    return (
      <div style={{ maxWidth: '640px', margin: '1rem auto' }}>
        <div className="receipt-card">
          <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
            <div
              style={{
                width: 60,
                height: 60,
                borderRadius: '50%',
                background: 'var(--emerald-50)',
                color: 'var(--emerald-600)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 1rem',
              }}
            >
              <CheckCircle2 size={36} />
            </div>
            <h1 style={{ fontSize: '1.6rem', color: 'var(--navy-900)' }}>Payment Confirmed!</h1>
            <p style={{ color: 'var(--slate-500)', fontSize: '0.875rem' }}>
              Your parking slot is securely reserved and activated for gate entry.
            </p>
          </div>

          {/* Key Allocation Banner */}
          <div
            style={{
              background: 'var(--slate-50)',
              border: '1px solid var(--slate-200)',
              borderRadius: 'var(--radius-md)',
              padding: '1.25rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '1.5rem',
            }}
          >
            <div>
              <span className="muted" style={{ fontSize: '0.75rem', textTransform: 'uppercase' }}>
                RESERVED PARKING BAY
              </span>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.85rem', fontWeight: 800, color: 'var(--navy-900)' }}>
                {reservation.slot_number}
              </div>
              <div style={{ fontSize: '0.825rem', color: 'var(--slate-500)' }}>
                Level {reservation.floor} &bull; {reservation.lot_name || 'Main Lot'}
              </div>
            </div>

            <div style={{ textAlign: 'right' }}>
              <QrCode size={52} color="var(--navy-900)" />
              <div style={{ fontSize: '0.65rem', fontFamily: 'var(--font-mono)', color: 'var(--slate-400)' }}>
                GATE ACCESS QR
              </div>
            </div>
          </div>

          {/* Receipt Breakdown */}
          <div className="receipt-row">
            <span className="muted">Transaction Reference:</span>
            <strong style={{ fontFamily: 'var(--font-mono)', fontSize: '0.85rem' }}>
              {paymentSuccessData.transaction_id}
            </strong>
          </div>
          <div className="receipt-row">
            <span className="muted">Vehicle License Plate:</span>
            <strong style={{ fontFamily: 'var(--font-mono)' }}>{reservation.vehicle_number || 'N/A'}</strong>
          </div>
          <div className="receipt-row">
            <span className="muted">Reserved Time Interval:</span>
            <span>
              {formatDateTime(reservation.start_time)} &rarr; {formatDateTime(reservation.end_time)}
            </span>
          </div>
          <div className="receipt-row">
            <span className="muted">Total Duration:</span>
            <span>{formatDuration(reservation.start_time, reservation.end_time)}</span>
          </div>
          <div className="receipt-row">
            <span className="muted">Payment Method:</span>
            <span style={{ textTransform: 'uppercase', fontWeight: 600 }}>{paymentSuccessData.method}</span>
          </div>
          <div className="receipt-row">
            <span className="muted">Gateway Provider:</span>
            <span>{paymentSuccessData.gateway_provider || 'IntelliPark Sandbox Demo'}</span>
          </div>
          <div className="receipt-total">
            <span>Total Amount Paid:</span>
            <span style={{ color: 'var(--emerald-600)' }}>{formatMoney(paymentSuccessData.amount)}</span>
          </div>

          {/* Simulated Disclaimer */}
          <div
            style={{
              margin: '1.5rem 0',
              padding: '0.75rem 1rem',
              background: 'var(--slate-50)',
              borderRadius: 'var(--radius-sm)',
              fontSize: '0.775rem',
              color: 'var(--slate-500)',
              textAlign: 'center',
            }}
          >
            Demonstration Mode &bull; Simulated digital payment transaction recorded in MongoDB.
          </div>

          {/* Action buttons */}
          <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1.5rem' }}>
            <button className="btn outline" style={{ flex: 1 }} onClick={() => window.print()}>
              <Printer size={15} />
              <span>Print Receipt</span>
            </button>
            <Link to="/reservations" className="btn primary" style={{ flex: 1 }}>
              <span>View My Bookings</span>
              <ArrowRight size={15} />
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Render Payment Checkout Form
  const durationHours = reservation.duration_hours || 1;
  const hourlyRate = reservation.hourly_rate || 40;
  const baseFare = durationHours * hourlyRate;
  const gst = 0; // included in pricing

  return (
    <div style={{ maxWidth: '840px', margin: '0 auto' }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <CreditCard size={26} color="var(--blue-600)" />
          <span>Complete Parking Reservation Payment</span>
        </h1>
        <p>Review your booking summary and choose a demonstration payment method.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1.5rem' }}>
        {/* Left Column: Reservation Summary & Fare Breakdown */}
        <div className="card">
          <h3 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Building size={18} />
            <span>Reservation Summary</span>
          </h3>

          <div
            style={{
              background: 'var(--slate-50)',
              border: '1px solid var(--slate-200)',
              borderRadius: 'var(--radius-sm)',
              padding: '1rem',
              marginBottom: '1.25rem',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.5rem' }}>
              <div>
                <span className="muted" style={{ fontSize: '0.75rem' }}>
                  ALLOCATED BAY
                </span>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.5rem', fontWeight: 800 }}>
                  {reservation.slot_number}
                </div>
              </div>
              <StatusBadge status={reservation.status} />
            </div>

            <div style={{ fontSize: '0.85rem', color: 'var(--slate-600)' }}>
              <div>Facility: <strong>{reservation.lot_name || 'Main Facility'}</strong></div>
              <div>Level: <strong>Floor {reservation.floor}</strong></div>
              <div>Vehicle Plate: <strong style={{ fontFamily: 'var(--font-mono)' }}>{reservation.vehicle_number || 'N/A'}</strong></div>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem', fontSize: '0.875rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span className="muted">Reserved From:</span>
              <strong>{formatDateTime(reservation.start_time)}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span className="muted">Reserved Until:</span>
              <strong>{formatDateTime(reservation.end_time)}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span className="muted">Billed Duration:</span>
              <strong>{durationHours} Hour{durationHours > 1 ? 's' : ''}</strong>
            </div>
          </div>

          <hr style={{ margin: '1.25rem 0', borderColor: 'var(--slate-200)' }} />

          <h4 style={{ marginBottom: '0.75rem' }}>Tariff Breakdown</h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.45rem', fontSize: '0.85rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>Base Rate ({formatMoney(hourlyRate)} &times; {durationHours} hr):</span>
              <span>{formatMoney(baseFare)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>Smart Sensor &amp; Proximity Fee:</span>
              <span style={{ color: 'var(--emerald-600)' }}>FREE (Waived)</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>Applicable Taxes (GST 18%):</span>
              <span className="muted">Included in fare</span>
            </div>
          </div>

          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginTop: '1.25rem',
              paddingTop: '1rem',
              borderTop: '2px dashed var(--slate-200)',
              fontSize: '1.25rem',
              fontWeight: 800,
              color: 'var(--navy-900)',
            }}
          >
            <span>Total Payable:</span>
            <span style={{ color: 'var(--blue-600)' }}>{formatMoney(reservation.amount)}</span>
          </div>
        </div>

        {/* Right Column: Payment Method & Sandbox Processing */}
        <div className="card">
          <h3 style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <ShieldCheck size={18} color="var(--emerald-600)" />
            <span>Select Payment Method</span>
          </h3>

          <form onSubmit={handlePay}>
            {/* Payment Method Selector Tabs */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '0.5rem', marginBottom: '1.25rem' }}>
              {PAYMENT_METHODS.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setSelectedMethod(m.id)}
                  className={`btn sm ${selectedMethod === m.id ? 'primary' : 'outline'}`}
                  style={{ fontSize: '0.75rem', padding: '0.5rem', justifyContent: 'flex-start' }}
                >
                  {m.label.split('(')[0]}
                </button>
              ))}
            </div>

            {/* Dynamic Inputs based on payment method */}
            {selectedMethod === 'upi' && (
              <div className="form-group">
                <label>UPI ID / Virtual Payment Address</label>
                <input
                  type="text"
                  className="form-input"
                  required
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  placeholder="e.g. driver@okhdfcbank"
                />
                <span className="form-help">Supported: Google Pay, PhonePe, Paytm, BHIM</span>
              </div>
            )}

            {selectedMethod === 'card' && (
              <>
                <div className="form-group">
                  <label>Card Number (Demo Sandbox)</label>
                  <input
                    type="text"
                    className="form-input"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                  />
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                  <div className="form-group">
                    <label>Expiry Date</label>
                    <input
                      type="text"
                      className="form-input"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                    />
                  </div>
                  <div className="form-group">
                    <label>CVV</label>
                    <input
                      type="password"
                      className="form-input"
                      maxLength={3}
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value)}
                    />
                  </div>
                </div>
              </>
            )}

            {selectedMethod === 'netbanking' && (
              <div className="form-group">
                <label>Select Retail Bank</label>
                <select className="form-select">
                  <option>State Bank of India (SBI)</option>
                  <option>HDFC Bank</option>
                  <option>ICICI Bank</option>
                  <option>Axis Bank</option>
                  <option>Kotak Mahindra Bank</option>
                </select>
              </div>
            )}

            {selectedMethod === 'cash' && (
              <div className="alert-banner info" style={{ marginBottom: '1.25rem' }}>
                <Clock size={16} />
                <span>
                  <strong>Pay at Barrier Gate:</strong> You can pay in cash or FASTag directly at the entry barrier terminal.
                </span>
              </div>
            )}

            {/* College DBMS Disclaimer Banner */}
            <div className="alert-banner info" style={{ marginBottom: '1.25rem', padding: '0.75rem 0.95rem' }}>
              <ShieldCheck size={18} />
              <div style={{ fontSize: '0.785rem' }}>
                <strong>Demonstration Mode:</strong> This checkout process simulates an online payment gateway (UPI/Card). In a production deployment, this links with Razorpay or Stripe webhooks.
              </div>
            </div>

            {paymentError && (
              <div className="alert-banner critical" style={{ marginBottom: '1.25rem' }}>
                <AlertTriangle size={16} />
                <span>{paymentError}</span>
              </div>
            )}

            <button
              type="submit"
              className="btn primary lg"
              style={{ width: '100%' }}
              disabled={submitting}
            >
              {submitting ? 'Processing Transaction...' : `Pay ${formatMoney(reservation.amount)} Now`}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
