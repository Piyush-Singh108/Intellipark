import { useState, useEffect, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { getSlots, getNearestSlot } from '../../services/slotService';
import { createReservation } from '../../services/reservationService';
import SlotCard from '../../components/user/SlotCard';
import ParkingSchematicMap from '../../components/user/ParkingSchematicMap';
import Modal from '../../components/common/Modal';
import Loader from '../../components/common/Loader';
import { formatMoney } from '../../utils/format';
import { SLOT_TYPES } from '../../utils/constants';
import {
  Search,
  Filter,
  RefreshCw,
  Sparkles,
  Map,
  Grid,
  Clock,
  ArrowUpDown,
  Car,
  AlertTriangle,
  Info,
  Calendar,
} from 'lucide-react';

export default function Dashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();

  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  // Filters & display state
  const [activeFloor, setActiveFloor] = useState(1);
  const [viewMode, setViewMode] = useState('map'); // 'map' or 'grid'
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [sortBy, setSortBy] = useState('slot_asc');

  // Nearest slot recommendation
  const [nearestSlot, setNearestSlot] = useState(null);
  const [nearestRationale, setNearestRationale] = useState('');

  // Reservation modal state
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [bookingForm, setBookingForm] = useState({
    start_time: '',
    end_time: '',
    vehicle_number: user?.vehicle_number || '',
  });
  const [bookingError, setBookingError] = useState('');
  const [bookingLoading, setBookingLoading] = useState(false);

  // Initialize start/end time default to next hour and 2 hours later
  useEffect(() => {
    const now = new Date();
    now.setMinutes(0, 0, 0);
    now.setHours(now.getHours() + 1);

    const pad = (n) => String(n).padStart(2, '0');
    const toLocalISO = (d) =>
      `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;

    const defaultStart = new Date(now.getTime());
    const defaultEnd = new Date(now.getTime() + 2 * 3600 * 1000);

    setBookingForm((prev) => ({
      ...prev,
      start_time: toLocalISO(defaultStart),
      end_time: toLocalISO(defaultEnd),
      vehicle_number: user?.vehicle_number || prev.vehicle_number || '',
    }));
  }, [user]);

  // Load slot data and nearest recommendation
  const fetchData = async (isRefetch = false) => {
    if (isRefetch) setRefreshing(true);
    else setLoading(true);
    setError('');

    try {
      const [allSlots, nearestRes] = await Promise.all([
        getSlots(),
        getNearestSlot({ floor: activeFloor }).catch(() => null),
      ]);

      setSlots(allSlots);
      if (nearestRes) {
        setNearestSlot(nearestRes.recommended_slot);
        setNearestRationale(nearestRes.rationale);
      } else {
        setNearestSlot(null);
      }

      // Check if redirected with a pre-selected slot
      if (location.state?.selectSlotId) {
        const found = allSlots.find((s) => s.slot_id === location.state.selectSlotId);
        if (found && found.status === 'available') {
          setSelectedSlot(found);
          setActiveFloor(found.floor);
        }
      }
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Error retrieving live parking bays.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
    // Auto-poll every 15 seconds for live availability
    const interval = setInterval(() => {
      fetchData(true);
    }, 15000);
    return () => clearInterval(interval);
  }, [activeFloor]);

  // Calculated estimated booking duration & price
  const estimatedPricing = useMemo(() => {
    if (!selectedSlot || !bookingForm.start_time || !bookingForm.end_time) {
      return { durationHours: 0, totalAmount: 0, isValid: false, message: '' };
    }

    const start = new Date(bookingForm.start_time);
    const end = new Date(bookingForm.end_time);

    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      return { durationHours: 0, totalAmount: 0, isValid: false, message: 'Invalid date format' };
    }

    if (start < new Date(Date.now() - 2 * 60000)) {
      return { durationHours: 0, totalAmount: 0, isValid: false, message: 'Start time must be in the future.' };
    }

    if (end <= start) {
      return { durationHours: 0, totalAmount: 0, isValid: false, message: 'End time must be after the start time.' };
    }

    const diffMinutes = (end - start) / 60000;
    if (diffMinutes < 30) {
      return { durationHours: 0, totalAmount: 0, isValid: false, message: 'Minimum booking duration is 30 minutes.' };
    }

    const durationHours = Math.max(1, Math.ceil(diffMinutes / 60));
    const totalAmount = durationHours * selectedSlot.hourly_rate;

    return { durationHours, totalAmount, isValid: true, message: '' };
  }, [selectedSlot, bookingForm.start_time, bookingForm.end_time]);

  // Filter and sort slots
  const filteredSlots = useMemo(() => {
    return slots
      .filter((s) => {
        // Floor filter (if viewMode is map, filter by activeFloor)
        if (viewMode === 'map' && Number(s.floor) !== Number(activeFloor)) return false;
        if (viewMode === 'grid' && activeFloor !== 'all' && Number(s.floor) !== Number(activeFloor)) return false;

        // Search term
        if (searchTerm) {
          const term = searchTerm.toLowerCase();
          const matchNumber = s.slot_number.toLowerCase().includes(term);
          const matchLot = s.lot_name?.toLowerCase().includes(term);
          if (!matchNumber && !matchLot) return false;
        }

        // Status
        if (statusFilter !== 'all' && s.status !== statusFilter) return false;

        // Type
        if (typeFilter !== 'all' && s.type !== typeFilter) return false;

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price_asc') return a.hourly_rate - b.hourly_rate;
        if (sortBy === 'price_desc') return b.hourly_rate - a.hourly_rate;
        if (sortBy === 'distance') return (a.distance_from_entrance || 10) - (b.distance_from_entrance || 10);
        return a.slot_number.localeCompare(b.slot_number, undefined, { numeric: true });
      });
  }, [slots, activeFloor, viewMode, searchTerm, statusFilter, typeFilter, sortBy]);

  // Handle slot reservation submit
  const handleReserve = async (e) => {
    e.preventDefault();
    setBookingError('');

    if (!estimatedPricing.isValid) {
      setBookingError(estimatedPricing.message || 'Please check reservation times.');
      return;
    }

    setBookingLoading(true);
    try {
      const res = await createReservation({
        slot_id: selectedSlot.slot_id,
        start_time: bookingForm.start_time,
        end_time: bookingForm.end_time,
        vehicle_number: bookingForm.vehicle_number || user?.vehicle_number,
      });

      setSelectedSlot(null);
      // Navigate to payment page for seamless completion
      navigate(`/pay/${res.reservation_id}`);
    } catch (err) {
      setBookingError(err.response?.data?.message || 'Could not complete reservation. Please try another slot.');
      fetchData(true);
    } finally {
      setBookingLoading(false);
    }
  };

  if (loading) return <Loader message="Loading facility layout and bay sensors..." />;
  if (error) return <Loader error={error} />;

  return (
    <div>
      {/* Page Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.25rem' }}>
        <div>
          <h1>Find &amp; Reserve Parking</h1>
          <p>Real-time slot sensors, smart entrance-proximity guidance, and instant reservations.</p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          {/* View mode toggle */}
          <div className="tab-pills">
            <button
              type="button"
              className={`tab-pill ${viewMode === 'map' ? 'active' : ''}`}
              onClick={() => setViewMode('map')}
            >
              <Map size={14} style={{ display: 'inline', marginRight: 4 }} /> Schematic Map
            </button>
            <button
              type="button"
              className={`tab-pill ${viewMode === 'grid' ? 'active' : ''}`}
              onClick={() => setViewMode('grid')}
            >
              <Grid size={14} style={{ display: 'inline', marginRight: 4 }} /> Grid View
            </button>
          </div>

          {/* Refresh button with pulse */}
          <button
            className="btn outline sm"
            onClick={() => fetchData(true)}
            disabled={refreshing}
            title="Refresh availability"
          >
            <RefreshCw size={14} className={refreshing ? 'spinner' : ''} />
            <span>{refreshing ? 'Syncing...' : 'Live Sync'}</span>
          </button>
        </div>
      </div>

      {/* Recommended Nearest Slot Banner */}
      {nearestSlot && (
        <div className="recommend-card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
            <div
              style={{
                width: 44,
                height: 44,
                borderRadius: 'var(--radius-sm)',
                background: 'var(--emerald-500)',
                color: '#fff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontFamily: 'var(--font-mono)',
                fontWeight: 700,
                fontSize: '1.1rem',
              }}
            >
              {nearestSlot.slot_number}
            </div>
            <div>
              <div className="recommend-badge">
                <Sparkles size={11} /> Nearest Available Recommendation
              </div>
              <div style={{ fontWeight: 700, fontSize: '0.95rem', color: 'var(--navy-900)' }}>
                {nearestRationale || `Closest bay on Floor ${nearestSlot.floor}`}
              </div>
              <div style={{ fontSize: '0.8rem', color: 'var(--slate-500)' }}>
                Rate: <strong>{formatMoney(nearestSlot.hourly_rate)}/hr</strong> &bull; Walking distance: ~{nearestSlot.distance_from_entrance}m
              </div>
            </div>
          </div>

          <button
            className="btn primary sm"
            onClick={() => {
              setSelectedSlot(nearestSlot);
              setActiveFloor(nearestSlot.floor);
            }}
          >
            Select Bay {nearestSlot.slot_number}
          </button>
        </div>
      )}

      {/* Floor Selector Pills */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem', marginBottom: '1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <span style={{ fontSize: '0.825rem', fontWeight: 700, color: 'var(--slate-500)', textTransform: 'uppercase' }}>
            Facility Level:
          </span>
          <div className="tab-pills">
            {viewMode === 'grid' && (
              <button
                type="button"
                className={`tab-pill ${activeFloor === 'all' ? 'active' : ''}`}
                onClick={() => setActiveFloor('all')}
              >
                All Levels
              </button>
            )}
            <button
              type="button"
              className={`tab-pill ${Number(activeFloor) === 1 ? 'active' : ''}`}
              onClick={() => setActiveFloor(1)}
            >
              Floor 1 (Ground Entry)
            </button>
            <button
              type="button"
              className={`tab-pill ${Number(activeFloor) === 2 ? 'active' : ''}`}
              onClick={() => setActiveFloor(2)}
            >
              Floor 2 (Mid Level)
            </button>
            <button
              type="button"
              className={`tab-pill ${Number(activeFloor) === 3 ? 'active' : ''}`}
              onClick={() => setActiveFloor(3)}
            >
              Floor 3 (Economy)
            </button>
          </div>
        </div>
      </div>

      {/* Filter and Search Toolbar */}
      <div className="toolbar-container">
        <div className="filter-group">
          {/* Search */}
          <div className="search-input-wrap">
            <Search size={15} className="search-icon" />
            <input
              type="text"
              className="form-input"
              placeholder="Search by bay (e.g. A-02)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ width: '220px' }}
            />
          </div>

          {/* Status Filter */}
          <select
            className="form-select"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="all">All Statuses</option>
            <option value="available">Available Only</option>
            <option value="occupied">Occupied</option>
            <option value="reserved">Reserved</option>
            <option value="maintenance">Maintenance</option>
          </select>

          {/* Type Filter */}
          <select
            className="form-select"
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
          >
            {SLOT_TYPES.map((t) => (
              <option key={t.id} value={t.id}>
                {t.label}
              </option>
            ))}
          </select>
        </div>

        {/* Sort Options */}
        <div className="filter-group">
          <ArrowUpDown size={15} color="var(--slate-400)" />
          <select
            className="form-select"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
          >
            <option value="slot_asc">Sort: Bay Number (A-Z)</option>
            <option value="distance">Sort: Closest to Entrance</option>
            <option value="price_asc">Sort: Price (Low to High)</option>
            <option value="price_desc">Sort: Price (High to Low)</option>
          </select>
        </div>
      </div>

      {/* Main Content: Schematic Map View OR Grid View */}
      {viewMode === 'map' ? (
        <div>
          <ParkingSchematicMap
            slots={slots}
            selectedSlot={selectedSlot}
            onSelectSlot={(slot) => setSelectedSlot(slot)}
            currentFloor={activeFloor === 'all' ? 1 : activeFloor}
          />

          <div style={{ margin: '1.5rem 0 0.75rem' }}>
            <h3>Bays on Floor {activeFloor === 'all' ? 1 : activeFloor}</h3>
          </div>

          {filteredSlots.length === 0 ? (
            <div className="empty-state">
              <Car className="empty-icon" />
              <div className="empty-title">No parking bays matched your filters</div>
              <div className="empty-description">
                Try resetting your search query or selecting a different status filter.
              </div>
              <button
                className="btn outline sm"
                onClick={() => {
                  setSearchTerm('');
                  setStatusFilter('all');
                  setTypeFilter('all');
                }}
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="slot-grid">
              {filteredSlots.map((slot) => (
                <SlotCard
                  key={slot.slot_id}
                  slot={slot}
                  onSelect={(s) => setSelectedSlot(s)}
                  isSelected={selectedSlot?.slot_id === slot.slot_id}
                />
              ))}
            </div>
          )}
        </div>
      ) : (
        /* Grid View */
        <div>
          {filteredSlots.length === 0 ? (
            <div className="empty-state">
              <Car className="empty-icon" />
              <div className="empty-title">No parking bays match your search criteria</div>
              <div className="empty-description">
                Try adjusting your search terms or clearing your status filters.
              </div>
              <button
                className="btn outline sm"
                onClick={() => {
                  setSearchTerm('');
                  setStatusFilter('all');
                  setTypeFilter('all');
                }}
              >
                Clear Filters
              </button>
            </div>
          ) : (
            <div className="slot-grid">
              {filteredSlots.map((slot) => (
                <SlotCard
                  key={slot.slot_id}
                  slot={slot}
                  onSelect={(s) => setSelectedSlot(s)}
                  isSelected={selectedSlot?.slot_id === slot.slot_id}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Reservation Drawer / Modal */}
      <Modal
        isOpen={!!selectedSlot}
        onClose={() => {
          setSelectedSlot(null);
          setBookingError('');
        }}
        title={`Reserve Parking Bay ${selectedSlot?.slot_number}`}
        footer={
          <>
            <button
              type="button"
              className="btn outline"
              onClick={() => {
                setSelectedSlot(null);
                setBookingError('');
              }}
            >
              Cancel
            </button>
            <button
              type="button"
              className="btn primary"
              onClick={handleReserve}
              disabled={!estimatedPricing.isValid || bookingLoading}
            >
              {bookingLoading ? 'Reserving...' : `Confirm & Pay ${formatMoney(estimatedPricing.totalAmount)}`}
            </button>
          </>
        }
      >
        {selectedSlot && (
          <form onSubmit={handleReserve}>
            {/* Slot Details Summary Box */}
            <div
              style={{
                background: 'var(--slate-50)',
                border: '1px solid var(--slate-200)',
                borderRadius: 'var(--radius-sm)',
                padding: '0.85rem 1rem',
                marginBottom: '1.25rem',
                display: 'grid',
                gridTemplateColumns: 'repeat(2, 1fr)',
                gap: '0.65rem',
                fontSize: '0.85rem',
              }}
            >
              <div>
                <span className="muted" style={{ display: 'block', fontSize: '0.75rem' }}>
                  PARKING BAY
                </span>
                <strong style={{ fontFamily: 'var(--font-mono)', fontSize: '1.1rem' }}>
                  {selectedSlot.slot_number}
                </strong>
              </div>
              <div>
                <span className="muted" style={{ display: 'block', fontSize: '0.75rem' }}>
                  LOCATION
                </span>
                <strong>Level {selectedSlot.floor} ({selectedSlot.lot_name})</strong>
              </div>
              <div>
                <span className="muted" style={{ display: 'block', fontSize: '0.75rem' }}>
                  HOURLY RATE
                </span>
                <strong>{formatMoney(selectedSlot.hourly_rate)} / hour</strong>
              </div>
              <div>
                <span className="muted" style={{ display: 'block', fontSize: '0.75rem' }}>
                  WALKING DISTANCE
                </span>
                <strong>~{selectedSlot.distance_from_entrance || 10}m to lift/entrance</strong>
              </div>
            </div>

            {/* Vehicle Number Input */}
            <div className="form-group">
              <label>Vehicle License Plate</label>
              <input
                type="text"
                className="form-input"
                required
                placeholder="e.g. MH12AB1234"
                value={bookingForm.vehicle_number}
                onChange={(e) => setBookingForm({ ...bookingForm, vehicle_number: e.target.value.toUpperCase() })}
              />
              <span className="form-help">License plate used for automated ANPR entry verification</span>
            </div>

            {/* Start Time Picker */}
            <div className="form-group">
              <label>
                <Clock size={13} style={{ display: 'inline', marginRight: 4 }} /> Reservation Start Time
              </label>
              <input
                type="datetime-local"
                className="form-input"
                required
                value={bookingForm.start_time}
                onChange={(e) => setBookingForm({ ...bookingForm, start_time: e.target.value })}
              />
            </div>

            {/* End Time Picker */}
            <div className="form-group">
              <label>
                <Clock size={13} style={{ display: 'inline', marginRight: 4 }} /> Reservation End Time
              </label>
              <input
                type="datetime-local"
                className="form-input"
                required
                value={bookingForm.end_time}
                onChange={(e) => setBookingForm({ ...bookingForm, end_time: e.target.value })}
              />
            </div>

            {/* Live Pricing Breakdown Box */}
            <div
              style={{
                background: estimatedPricing.isValid ? 'var(--blue-50)' : 'var(--rose-50)',
                border: `1px solid ${estimatedPricing.isValid ? 'var(--blue-200)' : 'var(--rose-200)'}`,
                borderRadius: 'var(--radius-sm)',
                padding: '0.85rem 1rem',
                margin: '1.25rem 0',
              }}
            >
              {estimatedPricing.isValid ? (
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.25rem' }}>
                    <span>Estimated Parking Duration:</span>
                    <strong>{estimatedPricing.durationHours} Hour{estimatedPricing.durationHours > 1 ? 's' : ''}</strong>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.25rem' }}>
                    <span>Base Hourly Fare ({formatMoney(selectedSlot.hourly_rate)} &times; {estimatedPricing.durationHours}h):</span>
                    <span>{formatMoney(estimatedPricing.totalAmount)}</span>
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      fontSize: '1rem',
                      fontWeight: 800,
                      color: 'var(--navy-900)',
                      paddingTop: '0.5rem',
                      borderTop: '1px dashed var(--blue-300)',
                      marginTop: '0.5rem',
                    }}
                  >
                    <span>Total Amount Payable:</span>
                    <span>{formatMoney(estimatedPricing.totalAmount)}</span>
                  </div>
                </div>
              ) : (
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--rose-600)', fontSize: '0.85rem' }}>
                  <AlertTriangle size={16} />
                  <span>{estimatedPricing.message || 'Please specify valid start and end times.'}</span>
                </div>
              )}
            </div>

            {/* Error Message */}
            {bookingError && (
              <div className="alert-banner critical" style={{ margin: '0 0 1rem', padding: '0.65rem 0.85rem' }}>
                <AlertTriangle size={16} />
                <span>{bookingError}</span>
              </div>
            )}
          </form>
        )}
      </Modal>
    </div>
  );
}
