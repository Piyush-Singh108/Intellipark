import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { getMyReservations, cancelReservation } from '../../services/reservationService';
import ReservationRow from '../../components/user/ReservationRow';
import StatusBadge from '../../components/common/StatusBadge';
import Modal from '../../components/common/Modal';
import Loader from '../../components/common/Loader';
import { formatDateTime, formatMoney, formatDuration } from '../../utils/format';
import {
  CalendarCheck,
  Search,
  CheckCircle2,
  AlertTriangle,
  QrCode,
  CreditCard,
  XCircle,
  FileText,
  Printer,
} from 'lucide-react';

export default function MyReservations() {
  const navigate = useNavigate();
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [activeTab, setActiveTab] = useState('all'); // 'all', 'confirmed', 'active', 'completed', 'cancelled'
  const [searchQuery, setSearchQuery] = useState('');

  // Cancellation Modal state
  const [resToCancel, setResToCancel] = useState(null);
  const [cancelReason, setCancelReason] = useState('Change of plans');
  const [cancelLoading, setCancelLoading] = useState(false);
  const [cancelError, setCancelError] = useState('');

  // Digital Pass / Receipt Modal state
  const [selectedPass, setSelectedPass] = useState(null);

  const fetchBookings = async () => {
    setLoading(true);
    setError('');
    try {
      const data = await getMyReservations();
      setReservations(data);
    } catch (err) {
      setError(err.response?.data?.message || 'Error loading reservations history.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  // Filtered reservations
  const filteredReservations = useMemo(() => {
    return reservations.filter((r) => {
      // Tab filter
      if (activeTab === 'confirmed' && r.status !== 'confirmed') return false;
      if (activeTab === 'active' && r.status !== 'active') return false;
      if (activeTab === 'completed' && r.status !== 'completed') return false;
      if (activeTab === 'cancelled' && r.status !== 'cancelled') return false;

      // Search query
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchSlot = r.slot_number?.toLowerCase().includes(q);
        const matchVehicle = r.vehicle_number?.toLowerCase().includes(q);
        const matchTxn = r.transaction_id?.toLowerCase().includes(q);
        if (!matchSlot && !matchVehicle && !matchTxn) return false;
      }

      return true;
    });
  }, [reservations, activeTab, searchQuery]);

  // Handle cancellation confirm
  const handleConfirmCancel = async () => {
    if (!resToCancel) return;
    setCancelLoading(true);
    setCancelError('');
    try {
      await cancelReservation(resToCancel.reservation_id, cancelReason);
      setResToCancel(null);
      fetchBookings();
    } catch (err) {
      setCancelError(err.response?.data?.message || 'Failed to cancel reservation.');
    } finally {
      setCancelLoading(false);
    }
  };

  if (loading) return <Loader message="Fetching your parking reservations..." />;
  if (error) return <Loader error={error} />;

  return (
    <div>
      {/* Page Title */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.5rem' }}>
        <div>
          <h1>My Parking Reservations</h1>
          <p>View your active parking passes, upcoming slots, booking history, and receipts.</p>
        </div>

        <button className="btn primary" onClick={() => navigate('/slots')}>
          Reserve New Bay
        </button>
      </div>

      {/* Tabs and Search Bar */}
      <div className="toolbar-container">
        <div className="tab-pills">
          <button
            type="button"
            className={`tab-pill ${activeTab === 'all' ? 'active' : ''}`}
            onClick={() => setActiveTab('all')}
          >
            All Bookings ({reservations.length})
          </button>
          <button
            type="button"
            className={`tab-pill ${activeTab === 'confirmed' ? 'active' : ''}`}
            onClick={() => setActiveTab('confirmed')}
          >
            Confirmed / Upcoming ({reservations.filter((r) => r.status === 'confirmed').length})
          </button>
          <button
            type="button"
            className={`tab-pill ${activeTab === 'active' ? 'active' : ''}`}
            onClick={() => setActiveTab('active')}
          >
            Parked / Active ({reservations.filter((r) => r.status === 'active').length})
          </button>
          <button
            type="button"
            className={`tab-pill ${activeTab === 'completed' ? 'active' : ''}`}
            onClick={() => setActiveTab('completed')}
          >
            Completed ({reservations.filter((r) => r.status === 'completed').length})
          </button>
          <button
            type="button"
            className={`tab-pill ${activeTab === 'cancelled' ? 'active' : ''}`}
            onClick={() => setActiveTab('cancelled')}
          >
            Cancelled ({reservations.filter((r) => r.status === 'cancelled').length})
          </button>
        </div>

        {/* Search */}
        <div className="search-input-wrap">
          <Search size={15} className="search-icon" />
          <input
            type="text"
            className="form-input"
            placeholder="Search by bay, vehicle, txn..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{ width: '220px' }}
          />
        </div>
      </div>

      {/* Bookings Table */}
      {filteredReservations.length === 0 ? (
        <div className="empty-state">
          <CalendarCheck className="empty-icon" />
          <div className="empty-title">No reservations found</div>
          <div className="empty-description">
            {searchQuery || activeTab !== 'all'
              ? 'No bookings match your selected filter criteria. Try resetting filters.'
              : 'You do not have any parking reservations yet. Find an available slot to get started.'}
          </div>
          <button className="btn primary" onClick={() => navigate('/slots')}>
            Explore Parking Bays
          </button>
        </div>
      ) : (
        <div className="table-card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Bay &amp; Level</th>
                  <th>Vehicle Plate</th>
                  <th>Reserved Time Interval</th>
                  <th>Fare</th>
                  <th>Booking Status</th>
                  <th>Payment Status</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredReservations.map((r) => (
                  <ReservationRow
                    key={r.reservation_id}
                    r={r}
                    onCancel={(res) => {
                      setResToCancel(res);
                      setCancelError('');
                    }}
                    onViewPass={(res) => setSelectedPass(res)}
                  />
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Cancellation Confirmation Modal */}
      <Modal
        isOpen={!!resToCancel}
        onClose={() => setResToCancel(null)}
        title="Cancel Parking Reservation"
        footer={
          <>
            <button className="btn outline" onClick={() => setResToCancel(null)}>
              Keep Reservation
            </button>
            <button
              className="btn danger"
              onClick={handleConfirmCancel}
              disabled={cancelLoading}
            >
              {cancelLoading ? 'Cancelling...' : 'Confirm Cancellation'}
            </button>
          </>
        }
      >
        {resToCancel && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem', color: 'var(--rose-600)' }}>
              <AlertTriangle size={24} />
              <p style={{ margin: 0, fontWeight: 600, color: 'inherit' }}>
                Are you sure you want to cancel your reservation for Bay {resToCancel.slot_number}?
              </p>
            </div>

            <p style={{ fontSize: '0.875rem', marginBottom: '1rem' }}>
              Your reservation from <strong>{formatDateTime(resToCancel.start_time)}</strong> until{' '}
              <strong>{formatDateTime(resToCancel.end_time)}</strong> will be released immediately for other drivers.
            </p>

            {resToCancel.payment_status === 'paid' && (
              <div className="alert-banner info" style={{ marginBottom: '1rem', padding: '0.65rem 0.85rem' }}>
                <CheckCircle2 size={16} />
                <span>
                  <strong>Simulated Refund:</strong> A refund of {formatMoney(resToCancel.amount)} will be automatically credited to your demo payment method.
                </span>
              </div>
            )}

            <div className="form-group">
              <label>Reason for Cancellation (Optional)</label>
              <select
                className="form-select"
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
              >
                <option value="Change of plans">Change of plans</option>
                <option value="Found alternative parking">Found alternative parking</option>
                <option value="Vehicle issue">Vehicle issue</option>
                <option value="Incorrect date or time selected">Incorrect date or time selected</option>
                <option value="Other">Other</option>
              </select>
            </div>

            {cancelError && (
              <div className="alert-banner critical" style={{ margin: '1rem 0 0' }}>
                <span>{cancelError}</span>
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* Digital Parking Pass & Receipt Modal */}
      <Modal
        isOpen={!!selectedPass}
        onClose={() => setSelectedPass(null)}
        title="Digital Parking Pass &amp; Receipt"
        footer={
          <>
            <button
              className="btn outline"
              onClick={() => window.print()}
              title="Print pass"
            >
              <Printer size={15} />
              <span>Print Pass</span>
            </button>
            <button className="btn primary" onClick={() => setSelectedPass(null)}>
              Close
            </button>
          </>
        }
      >
        {selectedPass && (
          <div className="receipt-card" style={{ padding: '0.5rem', boxShadow: 'none' }}>
            <div className="receipt-header">
              <div style={{ display: 'inline-flex', padding: '0.4rem 0.8rem', background: 'var(--navy-900)', color: '#fff', borderRadius: 'var(--radius-sm)', fontWeight: 800, letterSpacing: '-0.02em', marginBottom: '0.5rem' }}>
                INTELLIPARK SMART PASS
              </div>
              <h3>Parking Reservation Pass</h3>
              <p style={{ fontSize: '0.8rem', color: 'var(--slate-400)' }}>
                Booking Reference: #{String(selectedPass.reservation_id).slice(-8).toUpperCase()}
              </p>
            </div>

            {/* Big Bay Callout */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                background: 'var(--slate-50)',
                border: '1px solid var(--slate-200)',
                padding: '0.85rem 1.25rem',
                borderRadius: 'var(--radius-md)',
                marginBottom: '1.25rem',
              }}
            >
              <div>
                <span className="muted" style={{ fontSize: '0.75rem', textTransform: 'uppercase' }}>
                  ALLOCATED BAY
                </span>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.85rem', fontWeight: 800, color: 'var(--navy-900)' }}>
                  {selectedPass.slot_number}
                </div>
                <div style={{ fontSize: '0.8rem', color: 'var(--slate-500)' }}>
                  Level {selectedPass.floor} &bull; {selectedPass.lot_name || 'Main Facility'}
                </div>
              </div>

              <div style={{ textAlign: 'center' }}>
                <QrCode size={56} color="var(--navy-900)" />
                <div style={{ fontSize: '0.65rem', fontFamily: 'var(--font-mono)', color: 'var(--slate-400)' }}>
                  SCAN AT BARRIER
                </div>
              </div>
            </div>

            {/* Pass details table */}
            <div className="receipt-row">
              <span className="muted">Vehicle Plate</span>
              <strong style={{ fontFamily: 'var(--font-mono)' }}>{selectedPass.vehicle_number || 'N/A'}</strong>
            </div>
            <div className="receipt-row">
              <span className="muted">Valid From</span>
              <span>{formatDateTime(selectedPass.start_time)}</span>
            </div>
            <div className="receipt-row">
              <span className="muted">Valid Until</span>
              <span>{formatDateTime(selectedPass.end_time)}</span>
            </div>
            <div className="receipt-row">
              <span className="muted">Duration</span>
              <span>{formatDuration(selectedPass.start_time, selectedPass.end_time)}</span>
            </div>
            <div className="receipt-row">
              <span className="muted">Booking Status</span>
              <StatusBadge status={selectedPass.status} />
            </div>
            <div className="receipt-row">
              <span className="muted">Payment Status</span>
              <StatusBadge status={selectedPass.payment_status} />
            </div>
            {selectedPass.transaction_id && (
              <div className="receipt-row">
                <span className="muted">Transaction Ref</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8rem' }}>{selectedPass.transaction_id}</span>
              </div>
            )}
            <div className="receipt-total">
              <span>Total Fee:</span>
              <span>{formatMoney(selectedPass.amount)}</span>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
