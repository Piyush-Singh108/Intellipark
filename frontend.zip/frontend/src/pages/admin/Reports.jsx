import { useState, useEffect } from 'react';
import { getReports } from '../../services/adminService';
import Loader from '../../components/common/Loader';
import { formatMoney, formatDate } from '../../utils/format';
import {
  BarChart3,
  Download,
  Calendar,
  Layers,
  Sparkles,
  TrendingUp,
  CreditCard,
  CheckCircle2,
} from 'lucide-react';

export default function Reports() {
  const [days, setDays] = useState(14);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchReportsData = async () => {
    setLoading(true);
    setError('');
    try {
      const result = await getReports(days);
      setData(result);
    } catch (err) {
      setError(err.response?.data?.message || 'Error loading report aggregations.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReportsData();
  }, [days]);

  // Export CSV function
  const exportToCSV = () => {
    if (!data || !data.daily || data.daily.length === 0) {
      alert('No data available to export.');
      return;
    }

    const headers = ['Date', 'Reservations Count', 'Revenue (INR)'];
    const rows = data.daily.map((d) => [d.date, d.reservations, d.revenue]);

    let csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += headers.join(',') + '\r\n';
    rows.forEach((row) => {
      csvContent += row.join(',') + '\r\n';
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `intellipark_revenue_report_${days}days.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) return <Loader message="Executing MongoDB aggregation pipelines and generating analytics..." />;
  if (error) return <Loader error={error} />;
  if (!data) return null;

  // Compute summary metrics for the selected period
  const totalPeriodRevenue = data.daily.reduce((sum, d) => sum + (d.revenue || 0), 0);
  const totalPeriodBookings = data.daily.reduce((sum, d) => sum + (d.reservations || 0), 0);
  const avgBookingValue = totalPeriodBookings > 0 ? totalPeriodRevenue / totalPeriodBookings : 0;

  // Max revenue for scaling the SVG chart
  const maxRevenue = Math.max(...data.daily.map((d) => d.revenue || 0), 100);

  return (
    <div>
      {/* Title & Actions */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.5rem' }}>
        <div>
          <h1>Parking Analytics &amp; Reports</h1>
          <p>Real-time database aggregations, occupancy breakdown, and financial performance reports.</p>
        </div>

        <div style={{ display: 'flex', gap: '0.65rem' }}>
          {/* Days selector */}
          <div className="tab-pills">
            <button
              type="button"
              className={`tab-pill ${days === 7 ? 'active' : ''}`}
              onClick={() => setDays(7)}
            >
              Last 7 Days
            </button>
            <button
              type="button"
              className={`tab-pill ${days === 14 ? 'active' : ''}`}
              onClick={() => setDays(14)}
            >
              Last 14 Days
            </button>
            <button
              type="button"
              className={`tab-pill ${days === 30 ? 'active' : ''}`}
              onClick={() => setDays(30)}
            >
              Last 30 Days
            </button>
          </div>

          <button className="btn outline" onClick={exportToCSV} title="Export daily revenue data as CSV">
            <Download size={15} />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="stats-grid">
        <div className="stat-card emerald">
          <div className="stat-card-header">
            <span className="stat-card-label">Period Revenue</span>
            <div className="stat-icon-wrapper emerald">
              <TrendingUp size={18} />
            </div>
          </div>
          <div className="stat-card-value">{formatMoney(totalPeriodRevenue)}</div>
          <div className="stat-card-sub">Aggregated over past {days} days</div>
        </div>

        <div className="stat-card blue">
          <div className="stat-card-header">
            <span className="stat-card-label">Total Bookings</span>
            <div className="stat-icon-wrapper blue">
              <CheckCircle2 size={18} />
            </div>
          </div>
          <div className="stat-card-value">{totalPeriodBookings}</div>
          <div className="stat-card-sub">Paid reservations</div>
        </div>

        <div className="stat-card purple">
          <div className="stat-card-header">
            <span className="stat-card-label">Avg. Booking Value</span>
            <div className="stat-icon-wrapper purple">
              <CreditCard size={18} />
            </div>
          </div>
          <div className="stat-card-value">{formatMoney(avgBookingValue)}</div>
          <div className="stat-card-sub">Revenue per parking session</div>
        </div>
      </div>

      {/* Visual Daily Revenue Chart (SVG SaaS Bar Chart) */}
      <div className="card" style={{ marginBottom: '1.75rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
          <div>
            <h3>Daily Revenue Performance (Past {days} Days)</h3>
            <p style={{ fontSize: '0.825rem', color: 'var(--slate-500)', margin: 0 }}>
              Database pipeline: $match: status 'paid' &rarr; $group by date &rarr; $sum amount
            </p>
          </div>
          <span style={{ fontSize: '0.85rem', color: 'var(--slate-400)' }}>
            Peak Day: {formatMoney(maxRevenue)}
          </span>
        </div>

        {data.daily.length === 0 ? (
          <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--slate-400)' }}>
            No transaction records found for the selected time window.
          </div>
        ) : (
          <div style={{ width: '100%', overflowX: 'auto' }}>
            <div style={{ minWidth: '550px', height: '220px', display: 'flex', alignItems: 'flex-end', gap: '0.75rem', paddingBottom: '2.5rem', position: 'relative' }}>
              {data.daily.map((item, index) => {
                const heightPercent = Math.max(8, (item.revenue / maxRevenue) * 100);
                return (
                  <div
                    key={item.date}
                    style={{
                      flex: 1,
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      height: '100%',
                      justifyContent: 'flex-end',
                      position: 'relative',
                    }}
                  >
                    {/* Amount label above bar */}
                    <span style={{ fontSize: '0.675rem', fontWeight: 600, color: 'var(--slate-600)', marginBottom: '0.25rem' }}>
                      {formatMoney(item.revenue)}
                    </span>

                    {/* Bar element */}
                    <div
                      style={{
                        width: '100%',
                        maxWidth: '42px',
                        height: `${heightPercent}%`,
                        background: 'linear-gradient(180deg, var(--blue-500), var(--blue-600))',
                        borderRadius: '4px 4px 0 0',
                        transition: 'height 0.3s ease',
                        boxShadow: '0 2px 4px rgba(37,99,235,0.2)',
                      }}
                      title={`${item.date}: ${formatMoney(item.revenue)} (${item.reservations} bookings)`}
                    />

                    {/* Date label */}
                    <span
                      style={{
                        position: 'absolute',
                        bottom: '0.25rem',
                        fontSize: '0.7rem',
                        color: 'var(--slate-500)',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      {item.date.slice(5)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Two Analytics Sections: Floor Utilization & Top Used Slots */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))', gap: '1.5rem' }}>
        {/* Floor Utilization Breakdown */}
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
            <Layers size={18} />
            <h3>Floor-by-Floor Utilization</h3>
          </div>

          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Level</th>
                  <th>Total Bays</th>
                  <th>Available</th>
                  <th>Occupied / Reserved</th>
                  <th>Utilization</th>
                </tr>
              </thead>
              <tbody>
                {!data.floor_utilization || data.floor_utilization.length === 0 ? (
                  <tr>
                    <td colSpan="5" style={{ textAlign: 'center', color: 'var(--slate-400)' }}>
                      No floor data available.
                    </td>
                  </tr>
                ) : (
                  data.floor_utilization.map((f) => {
                    const utilPercent = Math.round(f.utilization_rate || 0);
                    return (
                      <tr key={f.floor}>
                        <td>
                          <strong>Level {f.floor}</strong>
                        </td>
                        <td>{f.total}</td>
                        <td>
                          <span style={{ color: 'var(--emerald-600)', fontWeight: 600 }}>{f.available}</span>
                        </td>
                        <td>{f.occupied + f.reserved}</td>
                        <td style={{ width: '35%' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <div
                              style={{
                                flex: 1,
                                height: 8,
                                background: 'var(--slate-200)',
                                borderRadius: 4,
                                overflow: 'hidden',
                              }}
                            >
                              <div
                                style={{
                                  width: `${utilPercent}%`,
                                  height: '100%',
                                  background: utilPercent > 75 ? 'var(--rose-500)' : 'var(--blue-500)',
                                }}
                              />
                            </div>
                            <span style={{ fontSize: '0.75rem', fontWeight: 700, width: '32px' }}>
                              {utilPercent}%
                            </span>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Most Used Parking Slots */}
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
            <Sparkles size={18} color="var(--amber-500)" />
            <h3>Most Frequently Reserved Bays</h3>
          </div>

          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Bay Number</th>
                  <th>Level</th>
                  <th>Hourly Rate</th>
                  <th>Total Bookings</th>
                  <th>Revenue Generated</th>
                </tr>
              </thead>
              <tbody>
                {!data.top_slots || data.top_slots.length === 0 ? (
                  <tr>
                    <td colSpan="5" style={{ textAlign: 'center', color: 'var(--slate-400)' }}>
                      No booking records found.
                    </td>
                  </tr>
                ) : (
                  data.top_slots.map((s, idx) => (
                    <tr key={s.slot_number}>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                          <span
                            style={{
                              width: 20,
                              height: 20,
                              borderRadius: '50%',
                              background: idx === 0 ? 'var(--amber-100)' : 'var(--slate-100)',
                              color: idx === 0 ? 'var(--amber-600)' : 'var(--slate-600)',
                              fontSize: '0.7rem',
                              fontWeight: 800,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                            }}
                          >
                            {idx + 1}
                          </span>
                          <strong style={{ fontFamily: 'var(--font-mono)' }}>{s.slot_number}</strong>
                        </div>
                      </td>
                      <td>Level {s.floor}</td>
                      <td>{formatMoney(s.hourly_rate)}</td>
                      <td>
                        <span className="badge" style={{ background: 'var(--blue-50)', color: 'var(--blue-600)' }}>
                          {s.bookings} times
                        </span>
                      </td>
                      <td>
                        <strong>{formatMoney(s.total_revenue || 0)}</strong>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
