import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getStats } from '../../services/adminService';
import StatCard from '../../components/admin/StatCard';
import StatusBadge from '../../components/common/StatusBadge';
import Loader from '../../components/common/Loader';
import { formatMoney, formatDateTime } from '../../utils/format';
import {
  Car,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Ban,
  Users,
  IndianRupee,
  Layers,
  BarChart3,
  DoorOpen,
  ArrowRight,
  TrendingUp,
  Percent,
} from 'lucide-react';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchDashboardStats = async () => {
    setLoading(true);
    setError('');
    try {
      const data = await getStats();
      setStats(data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load operations metrics.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardStats();
    // Auto-refresh every 20 seconds for real-time operations
    const interval = setInterval(fetchDashboardStats, 20000);
    return () => clearInterval(interval);
  }, []);

  if (loading) return <Loader message="Connecting to facility telemetry and operations database..." />;
  if (error) return <Loader error={error} />;
  if (!stats) return null;

  return (
    <div>
      {/* Top Operations Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.5rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
            <span className="badge available" style={{ fontSize: '0.75rem' }}>
              Facility Active
            </span>
            <span style={{ fontSize: '0.8rem', color: 'var(--slate-400)' }}>
              Central Smart Parking Operations
            </span>
          </div>
          <h1>Operations Command Center</h1>
          <p>Real-time occupancy metrics, gate telemetry, and automated transaction monitoring.</p>
        </div>

        {/* Quick action buttons */}
        <div style={{ display: 'flex', gap: '0.65rem', flexWrap: 'wrap' }}>
          <Link to="/admin/slots" className="btn primary">
            <Layers size={16} />
            <span>Manage Bays</span>
          </Link>
          <Link to="/admin/users" className="btn outline">
            <Users size={16} />
            <span>Users</span>
          </Link>
          <Link to="/admin/reports" className="btn outline">
            <BarChart3 size={16} />
            <span>Reports &amp; BI</span>
          </Link>
          <Link to="/terminal" className="btn outline">
            <DoorOpen size={16} />
            <span>Gate Terminal</span>
          </Link>
        </div>
      </div>

      {/* Facility Availability Alerts */}
      {stats.alerts && stats.alerts.length > 0 && (
        <div style={{ marginBottom: '1.5rem' }}>
          {stats.alerts.map((alert, idx) => (
            <div key={idx} className={`alert-banner ${alert.level}`}>
              <AlertTriangle size={18} />
              <div>
                <strong>Facility Alert:</strong> {alert.message}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Main KPI Stats Grid */}
      <div className="stats-grid">
        <StatCard
          label="Total Facility Bays"
          value={stats.total_slots}
          sub="Capacity across 3 floors"
          color="blue"
          icon={<Car size={18} />}
        />
        <StatCard
          label="Available Now"
          value={stats.available}
          sub="Open for reservation"
          color="emerald"
          icon={<CheckCircle2 size={18} />}
        />
        <StatCard
          label="Occupied Bays"
          value={stats.occupied}
          sub="Parked vehicles inside"
          color="rose"
          icon={<Car size={18} />}
        />
        <StatCard
          label="Reserved Bays"
          value={stats.reserved}
          sub="Imminent arrivals"
          color="amber"
          icon={<Clock size={18} />}
        />
        <StatCard
          label="Maintenance Bays"
          value={stats.maintenance}
          sub="Temporarily blocked"
          color="purple"
          icon={<Ban size={18} />}
        />
        <StatCard
          label="Facility Occupancy"
          value={`${stats.occupancy_rate}%`}
          sub="Utilization rate"
          color="blue"
          icon={<Percent size={18} />}
        />
        <StatCard
          label="Today's Revenue"
          value={formatMoney(stats.revenue_today)}
          sub="Paid bookings today"
          color="emerald"
          icon={<IndianRupee size={18} />}
        />
        <StatCard
          label="Registered Drivers"
          value={stats.total_users}
          sub="Verified accounts"
          color="purple"
          icon={<Users size={18} />}
        />
      </div>

      {/* Occupancy Progress Visual Meter */}
      <div className="card" style={{ marginBottom: '1.75rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
          <div>
            <h3>Live Facility Occupancy Distribution</h3>
            <p style={{ fontSize: '0.825rem', color: 'var(--slate-500)', margin: 0 }}>
              Visual representation of all {stats.total_slots} monitored parking bays.
            </p>
          </div>
          <span style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--navy-900)' }}>
            {stats.occupancy_rate}% Full
          </span>
        </div>

        {/* Multi-segment Progress Bar */}
        <div
          style={{
            height: '24px',
            width: '100%',
            backgroundColor: 'var(--slate-100)',
            borderRadius: 'var(--radius-sm)',
            overflow: 'hidden',
            display: 'flex',
            marginBottom: '0.85rem',
          }}
        >
          {/* Occupied (Rose) */}
          <div
            style={{
              width: `${stats.total_slots ? (stats.occupied / stats.total_slots) * 100 : 0}%`,
              background: 'var(--rose-500)',
              transition: 'width 0.4s ease',
            }}
            title={`Occupied: ${stats.occupied}`}
          />
          {/* Reserved (Amber) */}
          <div
            style={{
              width: `${stats.total_slots ? (stats.reserved / stats.total_slots) * 100 : 0}%`,
              background: 'var(--amber-500)',
              transition: 'width 0.4s ease',
            }}
            title={`Reserved: ${stats.reserved}`}
          />
          {/* Maintenance (Slate) */}
          <div
            style={{
              width: `${stats.total_slots ? (stats.maintenance / stats.total_slots) * 100 : 0}%`,
              background: 'var(--slate-400)',
              transition: 'width 0.4s ease',
            }}
            title={`Maintenance: ${stats.maintenance}`}
          />
          {/* Available (Emerald) */}
          <div
            style={{
              width: `${stats.total_slots ? (stats.available / stats.total_slots) * 100 : 0}%`,
              background: 'var(--emerald-500)',
              transition: 'width 0.4s ease',
            }}
            title={`Available: ${stats.available}`}
          />
        </div>

        {/* Meter Legend */}
        <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap', fontSize: '0.8rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: 'var(--emerald-500)' }} />
            <span>Available ({stats.available})</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: 'var(--rose-500)' }} />
            <span>Occupied ({stats.occupied})</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: 'var(--amber-500)' }} />
            <span>Reserved ({stats.reserved})</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: 'var(--slate-400)' }} />
            <span>Maintenance ({stats.maintenance})</span>
          </div>
        </div>
      </div>

      {/* Dual Activity Feeds: Recent Reservations & Recent Transactions */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))', gap: '1.5rem' }}>
        {/* Recent Reservations Table */}
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
            <h3>Recent Parking Reservations</h3>
            <Link to="/admin/reports" className="btn outline sm">
              View All
            </Link>
          </div>

          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Driver &amp; Vehicle</th>
                  <th>Bay</th>
                  <th>Interval</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {!stats.recent_reservations || stats.recent_reservations.length === 0 ? (
                  <tr>
                    <td colSpan="4" style={{ textAlign: 'center', padding: '1.5rem', color: 'var(--slate-400)' }}>
                      No recent reservations recorded.
                    </td>
                  </tr>
                ) : (
                  stats.recent_reservations.map((r) => (
                    <tr key={r._id}>
                      <td>
                        <strong>{r.user?.name || 'Driver'}</strong>
                        <div style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', color: 'var(--slate-500)' }}>
                          {r.vehicle_number || r.user?.vehicle_number || 'N/A'}
                        </div>
                      </td>
                      <td>
                        <strong style={{ fontFamily: 'var(--font-mono)' }}>{r.slot?.slot_number}</strong>
                        <div style={{ fontSize: '0.75rem', color: 'var(--slate-400)' }}>L{r.slot?.floor}</div>
                      </td>
                      <td>
                        <div style={{ fontSize: '0.75rem' }}>{formatDateTime(r.start_time)}</div>
                        <div style={{ fontSize: '0.7rem', color: 'var(--slate-400)' }}>to {formatDateTime(r.end_time)}</div>
                      </td>
                      <td>
                        <StatusBadge status={r.status} />
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Transactions Feed */}
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
            <h3>Recent Digital Payments</h3>
            <Link to="/admin/reports" className="btn outline sm">
              Revenue Reports
            </Link>
          </div>

          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Txn ID &amp; User</th>
                  <th>Amount</th>
                  <th>Method</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {!stats.recent_payments || stats.recent_payments.length === 0 ? (
                  <tr>
                    <td colSpan="4" style={{ textAlign: 'center', padding: '1.5rem', color: 'var(--slate-400)' }}>
                      No payments processed yet.
                    </td>
                  </tr>
                ) : (
                  stats.recent_payments.map((p) => (
                    <tr key={p._id}>
                      <td>
                        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--slate-600)' }}>
                          {p.transaction_id}
                        </div>
                        <strong style={{ fontSize: '0.85rem' }}>{p.user?.name || 'Driver'}</strong>
                      </td>
                      <td>
                        <strong style={{ color: 'var(--emerald-600)' }}>{formatMoney(p.amount)}</strong>
                      </td>
                      <td>
                        <span style={{ textTransform: 'uppercase', fontSize: '0.75rem', fontWeight: 600 }}>
                          {p.method}
                        </span>
                      </td>
                      <td>
                        <StatusBadge status={p.status} />
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
