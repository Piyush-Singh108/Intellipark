import { useState, useEffect, useMemo } from 'react';
import { getSlots } from '../../services/slotService';
import {
  createSlot,
  updateSlot,
  updateSlotStatus,
  deleteSlot,
} from '../../services/adminService';
import SlotTable from '../../components/admin/SlotTable';
import Modal from '../../components/common/Modal';
import Loader from '../../components/common/Loader';
import { SLOT_TYPES } from '../../utils/constants';
import {
  Plus,
  Search,
  Filter,
  RefreshCw,
  AlertTriangle,
  Layers,
  Edit2,
  Trash2,
} from 'lucide-react';

export default function ManageSlots() {
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  // Filters
  const [floorFilter, setFloorFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Add Slot Modal state
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [addForm, setAddForm] = useState({
    slot_number: '',
    lot_name: 'Main Lot',
    floor: 1,
    hourly_rate: 40,
    type: 'standard',
    distance_from_entrance: 15,
  });
  const [addError, setAddError] = useState('');
  const [addLoading, setAddLoading] = useState(false);

  // Edit Slot Modal state
  const [editingSlot, setEditingSlot] = useState(null);
  const [editForm, setEditForm] = useState({
    slot_number: '',
    lot_name: 'Main Lot',
    floor: 1,
    hourly_rate: 40,
    type: 'standard',
    distance_from_entrance: 15,
    status: 'available',
  });
  const [editError, setEditError] = useState('');
  const [editLoading, setEditLoading] = useState(false);

  // Delete Confirmation Modal state
  const [deletingSlot, setDeletingSlot] = useState(null);
  const [deleteError, setDeleteError] = useState('');
  const [deleteLoading, setDeleteLoading] = useState(false);

  // General Notification / Alert
  const [actionSuccess, setActionSuccess] = useState('');

  const fetchSlots = async (isRefetch = false) => {
    if (isRefetch) setRefreshing(true);
    else setLoading(true);
    setError('');
    try {
      const data = await getSlots();
      setSlots(data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to fetch parking bays.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchSlots();
  }, []);

  // Filtered Slots
  const filteredSlots = useMemo(() => {
    return slots.filter((s) => {
      if (floorFilter !== 'all' && Number(s.floor) !== Number(floorFilter)) return false;
      if (statusFilter !== 'all' && s.status !== statusFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        if (!s.slot_number.toLowerCase().includes(q) && !s.lot_name?.toLowerCase().includes(q)) {
          return false;
        }
      }
      return true;
    });
  }, [slots, floorFilter, statusFilter, searchQuery]);

  // Quick Status change
  const handleQuickStatus = async (id, status) => {
    try {
      await updateSlotStatus(id, status);
      setActionSuccess(`Bay status updated to ${status}.`);
      setTimeout(() => setActionSuccess(''), 3000);
      fetchSlots(true);
    } catch (err) {
      alert(err.response?.data?.message || 'Error updating slot status.');
    }
  };

  // Add Slot Submit
  const handleAddSubmit = async (e) => {
    e.preventDefault();
    setAddError('');
    setAddLoading(true);

    try {
      await createSlot(addForm);
      setIsAddOpen(false);
      setAddForm({
        slot_number: '',
        lot_name: 'Main Lot',
        floor: 1,
        hourly_rate: 40,
        type: 'standard',
        distance_from_entrance: 15,
      });
      setActionSuccess(`New bay created successfully.`);
      setTimeout(() => setActionSuccess(''), 3000);
      fetchSlots(true);
    } catch (err) {
      setAddError(err.response?.data?.message || 'Failed to create slot. Check unique slot number.');
    } finally {
      setAddLoading(false);
    }
  };

  // Open Edit Modal
  const openEdit = (slot) => {
    setEditingSlot(slot);
    setEditForm({
      slot_number: slot.slot_number,
      lot_name: slot.lot_name || 'Main Lot',
      floor: slot.floor || 1,
      hourly_rate: slot.hourly_rate || 40,
      type: slot.type || 'standard',
      distance_from_entrance: slot.distance_from_entrance || 15,
      status: slot.status || 'available',
    });
    setEditError('');
  };

  // Edit Slot Submit
  const handleEditSubmit = async (e) => {
    e.preventDefault();
    if (!editingSlot) return;
    setEditError('');
    setEditLoading(true);

    try {
      await updateSlot(editingSlot.slot_id, editForm);
      setEditingSlot(null);
      setActionSuccess(`Bay ${editForm.slot_number} updated.`);
      setTimeout(() => setActionSuccess(''), 3000);
      fetchSlots(true);
    } catch (err) {
      setEditError(err.response?.data?.message || 'Failed to update slot.');
    } finally {
      setEditLoading(false);
    }
  };

  // Open Delete Confirmation
  const openDelete = (slotId, slotNumber) => {
    setDeletingSlot({ slot_id: slotId, slot_number: slotNumber });
    setDeleteError('');
  };

  // Delete Confirm
  const handleDeleteConfirm = async () => {
    if (!deletingSlot) return;
    setDeleteError('');
    setDeleteLoading(true);

    try {
      await deleteSlot(deletingSlot.slot_id);
      setDeletingSlot(null);
      setActionSuccess(`Bay ${deletingSlot.slot_number} deleted.`);
      setTimeout(() => setActionSuccess(''), 3000);
      fetchSlots(true);
    } catch (err) {
      setDeleteError(err.response?.data?.message || 'Failed to delete slot.');
    } finally {
      setDeleteLoading(false);
    }
  };

  if (loading) return <Loader message="Loading parking bay registry..." />;
  if (error) return <Loader error={error} />;

  return (
    <div>
      {/* Page Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.25rem' }}>
        <div>
          <h1>Parking Bays Management</h1>
          <p>Create new parking bays, calibrate hourly rates, adjust statuses, and manage facility layout.</p>
        </div>

        <div style={{ display: 'flex', gap: '0.65rem' }}>
          <button className="btn outline" onClick={() => fetchSlots(true)} disabled={refreshing}>
            <RefreshCw size={15} className={refreshing ? 'spinner' : ''} />
            <span>Sync</span>
          </button>
          <button className="btn primary" onClick={() => setIsAddOpen(true)}>
            <Plus size={16} />
            <span>Add New Bay</span>
          </button>
        </div>
      </div>

      {/* Success notification banner */}
      {actionSuccess && (
        <div className="alert-banner success" style={{ marginBottom: '1.25rem' }}>
          <span>{actionSuccess}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="toolbar-container">
        <div className="filter-group">
          {/* Search */}
          <div className="search-input-wrap">
            <Search size={15} className="search-icon" />
            <input
              type="text"
              className="form-input"
              placeholder="Search bay number (e.g. A-01)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{ width: '220px' }}
            />
          </div>

          {/* Floor filter */}
          <select
            className="form-select"
            value={floorFilter}
            onChange={(e) => setFloorFilter(e.target.value)}
          >
            <option value="all">All Levels</option>
            <option value="1">Floor 1 (Ground)</option>
            <option value="2">Floor 2 (Mid Level)</option>
            <option value="3">Floor 3 (Economy)</option>
          </select>

          {/* Status filter */}
          <select
            className="form-select"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="all">All Statuses</option>
            <option value="available">Available</option>
            <option value="occupied">Occupied</option>
            <option value="reserved">Reserved</option>
            <option value="maintenance">Maintenance</option>
          </select>
        </div>

        <div style={{ fontSize: '0.85rem', color: 'var(--slate-500)' }}>
          Showing <strong>{filteredSlots.length}</strong> of <strong>{slots.length}</strong> bays
        </div>
      </div>

      {/* Slot Table */}
      <SlotTable
        slots={filteredSlots}
        onStatus={handleQuickStatus}
        onEdit={openEdit}
        onDelete={openDelete}
      />

      {/* Add Slot Modal */}
      <Modal
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        title="Add New Parking Bay"
        footer={
          <>
            <button type="button" className="btn outline" onClick={() => setIsAddOpen(false)}>
              Cancel
            </button>
            <button
              type="button"
              className="btn primary"
              onClick={handleAddSubmit}
              disabled={addLoading}
            >
              {addLoading ? 'Creating Bay...' : 'Save & Register Bay'}
            </button>
          </>
        }
      >
        <form onSubmit={handleAddSubmit}>
          <div className="form-group">
            <label>Bay Number (Unique Identifier)</label>
            <input
              type="text"
              className="form-input"
              required
              placeholder="e.g. A-09 or C-07"
              value={addForm.slot_number}
              onChange={(e) => setAddForm({ ...addForm, slot_number: e.target.value.toUpperCase() })}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <div className="form-group">
              <label>Floor / Level</label>
              <select
                className="form-select"
                value={addForm.floor}
                onChange={(e) => setAddForm({ ...addForm, floor: Number(e.target.value) })}
              >
                <option value={1}>Floor 1 (Ground)</option>
                <option value={2}>Floor 2</option>
                <option value={3}>Floor 3</option>
              </select>
            </div>

            <div className="form-group">
              <label>Bay Type</label>
              <select
                className="form-select"
                value={addForm.type}
                onChange={(e) => setAddForm({ ...addForm, type: e.target.value })}
              >
                <option value="standard">Standard Bay</option>
                <option value="ev_charging">EV Fast Charging</option>
                <option value="handicapped">Accessible (Disabled)</option>
                <option value="vip">VIP Reserved</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <div className="form-group">
              <label>Hourly Rate (₹)</label>
              <input
                type="number"
                min="0"
                className="form-input"
                required
                value={addForm.hourly_rate}
                onChange={(e) => setAddForm({ ...addForm, hourly_rate: Number(e.target.value) })}
              />
            </div>

            <div className="form-group">
              <label>Walking Distance (meters)</label>
              <input
                type="number"
                min="1"
                className="form-input"
                required
                value={addForm.distance_from_entrance}
                onChange={(e) => setAddForm({ ...addForm, distance_from_entrance: Number(e.target.value) })}
              />
            </div>
          </div>

          <div className="form-group">
            <label>Lot / Section Name</label>
            <input
              type="text"
              className="form-input"
              value={addForm.lot_name}
              onChange={(e) => setAddForm({ ...addForm, lot_name: e.target.value })}
            />
          </div>

          {addError && (
            <div className="alert-banner critical" style={{ margin: '1rem 0 0' }}>
              <AlertTriangle size={16} />
              <span>{addError}</span>
            </div>
          )}
        </form>
      </Modal>

      {/* Edit Slot Modal */}
      <Modal
        isOpen={!!editingSlot}
        onClose={() => setEditingSlot(null)}
        title={`Edit Parking Bay ${editingSlot?.slot_number}`}
        footer={
          <>
            <button type="button" className="btn outline" onClick={() => setEditingSlot(null)}>
              Cancel
            </button>
            <button
              type="button"
              className="btn primary"
              onClick={handleEditSubmit}
              disabled={editLoading}
            >
              {editLoading ? 'Saving...' : 'Save Changes'}
            </button>
          </>
        }
      >
        {editingSlot && (
          <form onSubmit={handleEditSubmit}>
            <div className="form-group">
              <label>Bay Number</label>
              <input
                type="text"
                className="form-input"
                required
                value={editForm.slot_number}
                onChange={(e) => setEditForm({ ...editForm, slot_number: e.target.value.toUpperCase() })}
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              <div className="form-group">
                <label>Floor</label>
                <select
                  className="form-select"
                  value={editForm.floor}
                  onChange={(e) => setEditForm({ ...editForm, floor: Number(e.target.value) })}
                >
                  <option value={1}>Floor 1</option>
                  <option value={2}>Floor 2</option>
                  <option value={3}>Floor 3</option>
                </select>
              </div>

              <div className="form-group">
                <label>Bay Type</label>
                <select
                  className="form-select"
                  value={editForm.type}
                  onChange={(e) => setEditForm({ ...editForm, type: e.target.value })}
                >
                  <option value="standard">Standard Bay</option>
                  <option value="ev_charging">EV Fast Charging</option>
                  <option value="handicapped">Accessible (Disabled)</option>
                  <option value="vip">VIP Reserved</option>
                </select>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              <div className="form-group">
                <label>Hourly Rate (₹)</label>
                <input
                  type="number"
                  min="0"
                  className="form-input"
                  required
                  value={editForm.hourly_rate}
                  onChange={(e) => setEditForm({ ...editForm, hourly_rate: Number(e.target.value) })}
                />
              </div>

              <div className="form-group">
                <label>Distance to Entrance (m)</label>
                <input
                  type="number"
                  min="1"
                  className="form-input"
                  required
                  value={editForm.distance_from_entrance}
                  onChange={(e) => setEditForm({ ...editForm, distance_from_entrance: Number(e.target.value) })}
                />
              </div>
            </div>

            <div className="form-group">
              <label>Status</label>
              <select
                className="form-select"
                value={editForm.status}
                onChange={(e) => setEditForm({ ...editForm, status: e.target.value })}
              >
                <option value="available">Available</option>
                <option value="occupied">Occupied</option>
                <option value="reserved">Reserved</option>
                <option value="maintenance">Maintenance</option>
              </select>
            </div>

            {editError && (
              <div className="alert-banner critical" style={{ margin: '1rem 0 0' }}>
                <AlertTriangle size={16} />
                <span>{editError}</span>
              </div>
            )}
          </form>
        )}
      </Modal>

      {/* Delete Slot Confirmation Modal */}
      <Modal
        isOpen={!!deletingSlot}
        onClose={() => setDeletingSlot(null)}
        title="Delete Parking Bay"
        footer={
          <>
            <button className="btn outline" onClick={() => setDeletingSlot(null)}>
              Cancel
            </button>
            <button
              className="btn danger"
              onClick={handleDeleteConfirm}
              disabled={deleteLoading}
            >
              {deleteLoading ? 'Deleting...' : 'Delete Slot Permanently'}
            </button>
          </>
        }
      >
        {deletingSlot && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem', color: 'var(--rose-600)' }}>
              <AlertTriangle size={24} />
              <p style={{ margin: 0, fontWeight: 600, color: 'inherit' }}>
                Are you sure you want to delete parking bay {deletingSlot.slot_number}?
              </p>
            </div>

            <p style={{ fontSize: '0.875rem', marginBottom: '1rem' }}>
              The database will automatically verify referential integrity to prevent deleting slots with active or confirmed driver reservations.
            </p>

            {deleteError && (
              <div className="alert-banner critical">
                <AlertTriangle size={16} />
                <span>{deleteError}</span>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
