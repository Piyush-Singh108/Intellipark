import { useState, useEffect, useMemo } from 'react';
import { getUsers, deleteUser } from '../../services/adminService';
import Modal from '../../components/common/Modal';
import Loader from '../../components/common/Loader';
import { formatDateTime, formatMoney } from '../../utils/format';
import {
  Users,
  Search,
  Trash2,
  AlertTriangle,
  RefreshCw,
  Car,
  Mail,
  Phone,
  Calendar,
} from 'lucide-react';

export default function ManageUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // Delete modal state
  const [userToDelete, setUserToDelete] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteError, setDeleteError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const fetchUsersList = async (isRefetch = false) => {
    if (isRefetch) setRefreshing(true);
    else setLoading(true);
    setError('');
    try {
      const data = await getUsers();
      setUsers(data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to retrieve users directory.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchUsersList();
  }, []);

  const filteredUsers = useMemo(() => {
    if (!searchQuery) return users;
    const q = searchQuery.toLowerCase();
    return users.filter(
      (u) =>
        u.name?.toLowerCase().includes(q) ||
        u.email?.toLowerCase().includes(q) ||
        u.vehicle_number?.toLowerCase().includes(q) ||
        u.phone?.toLowerCase().includes(q)
    );
  }, [users, searchQuery]);

  const handleDeleteUserConfirm = async () => {
    if (!userToDelete) return;
    setDeleteError('');
    setDeleteLoading(true);

    try {
      const res = await deleteUser(userToDelete._id);
      setUserToDelete(null);
      setSuccessMsg(res.message || 'User deleted successfully.');
      setTimeout(() => setSuccessMsg(''), 3000);
      fetchUsersList(true);
    } catch (err) {
      setDeleteError(err.response?.data?.message || 'Failed to delete user.');
    } finally {
      setDeleteLoading(false);
    }
  };

  if (loading) return <Loader message="Loading registered users directory..." />;
  if (error) return <Loader error={error} />;

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.25rem' }}>
        <div>
          <h1>Registered Drivers &amp; Users</h1>
          <p>Directory of registered drivers, vehicle profiles, aggregate booking metrics, and administrative access.</p>
        </div>

        <button className="btn outline" onClick={() => fetchUsersList(true)} disabled={refreshing}>
          <RefreshCw size={15} className={refreshing ? 'spinner' : ''} />
          <span>Refresh</span>
        </button>
      </div>

      {successMsg && (
        <div className="alert-banner success" style={{ marginBottom: '1.25rem' }}>
          <span>{successMsg}</span>
        </div>
      )}

      {/* Search Toolbar */}
      <div className="toolbar-container">
        <div className="search-input-wrap">
          <Search size={15} className="search-icon" />
          <input
            type="text"
            className="form-input"
            placeholder="Search by driver name, email, or vehicle plate..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{ width: '320px' }}
          />
        </div>

        <div style={{ fontSize: '0.85rem', color: 'var(--slate-500)' }}>
          Total Registered Drivers: <strong>{users.length}</strong>
        </div>
      </div>

      {/* Users Table */}
      <div className="table-card">
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Driver Name</th>
                <th>Contact Details</th>
                <th>Registered Vehicle</th>
                <th>Registration Date</th>
                <th>Lifetime Bookings</th>
                <th>Total Spent</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '2rem', color: 'var(--slate-500)' }}>
                    No users found matching your search.
                  </td>
                </tr>
              ) : (
                filteredUsers.map((u) => (
                  <tr key={u._id}>
                    <td>
                      <strong>{u.name}</strong>
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.8rem', color: 'var(--slate-600)' }}>
                        <Mail size={12} /> {u.email}
                      </div>
                      {u.phone && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.75rem', color: 'var(--slate-400)' }}>
                          <Phone size={11} /> {u.phone}
                        </div>
                      )}
                    </td>
                    <td>
                      <span
                        style={{
                          fontFamily: 'var(--font-mono)',
                          fontSize: '0.85rem',
                          padding: '0.2rem 0.5rem',
                          background: 'var(--slate-100)',
                          borderRadius: 'var(--radius-sm)',
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '0.35rem',
                        }}
                      >
                        <Car size={12} /> {u.vehicle_number || 'None'}
                      </span>
                    </td>
                    <td>
                      <span style={{ fontSize: '0.825rem', color: 'var(--slate-500)' }}>
                        {formatDateTime(u.created_at)}
                      </span>
                    </td>
                    <td>
                      <span className="badge" style={{ background: 'var(--blue-50)', color: 'var(--blue-600)', border: '1px solid var(--blue-100)' }}>
                        {u.total_reservations || 0} Bookings
                      </span>
                    </td>
                    <td>
                      <strong>{formatMoney(u.total_spent || 0)}</strong>
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <button
                        className="btn danger sm"
                        onClick={() => {
                          setUserToDelete(u);
                          setDeleteError('');
                        }}
                        title="Delete user account"
                      >
                        <Trash2 size={13} />
                        <span>Delete</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete User Modal */}
      <Modal
        isOpen={!!userToDelete}
        onClose={() => setUserToDelete(null)}
        title="Delete User Account"
        footer={
          <>
            <button className="btn outline" onClick={() => setUserToDelete(null)}>
              Cancel
            </button>
            <button
              className="btn danger"
              onClick={handleDeleteUserConfirm}
              disabled={deleteLoading}
            >
              {deleteLoading ? 'Deleting...' : 'Confirm Delete User'}
            </button>
          </>
        }
      >
        {userToDelete && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem', color: 'var(--rose-600)' }}>
              <AlertTriangle size={24} />
              <p style={{ margin: 0, fontWeight: 600, color: 'inherit' }}>
                Are you sure you want to delete user "{userToDelete.name}" ({userToDelete.email})?
              </p>
            </div>

            <p style={{ fontSize: '0.875rem', marginBottom: '1rem' }}>
              The database will enforce integrity constraints: users with active or upcoming confirmed reservations cannot be deleted.
            </p>

            {deleteError && (
              <div className="alert-banner critical">
                <AlertTriangle size={16} />
                <span>{deleteError}</span>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
