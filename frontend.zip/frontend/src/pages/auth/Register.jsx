import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { register } from '../../services/authService';
import { Car, Lock, Mail, User, Phone, ArrowRight, AlertTriangle } from 'lucide-react';

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    vehicle_number: '',
    password: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await register({
        ...form,
        vehicle_number: form.vehicle_number.toUpperCase().trim(),
      });
      navigate('/login');
    } catch (err) {
      setError(err.response?.data?.message || 'Could not create account. Please verify input fields.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page-wrapper">
      <div className="auth-card" style={{ maxWidth: '480px' }}>
        <div className="auth-header">
          <div
            style={{
              width: 52,
              height: 52,
              borderRadius: 'var(--radius-sm)',
              background: 'var(--emerald-600)',
              color: '#fff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 1rem',
            }}
          >
            <Car size={28} />
          </div>
          <h1>Create Driver Account</h1>
          <p>Register your vehicle for automated smart parking access</p>
        </div>

        <form onSubmit={onSubmit}>
          <div className="form-group">
            <label>Full Name</label>
            <div className="search-input-wrap">
              <User size={16} className="search-icon" />
              <input
                type="text"
                className="form-input"
                required
                value={form.name}
                onChange={set('name')}
                placeholder="John Doe"
                style={{ width: '100%' }}
              />
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <div className="form-group">
              <label>Email Address</label>
              <div className="search-input-wrap">
                <Mail size={16} className="search-icon" />
                <input
                  type="email"
                  className="form-input"
                  required
                  value={form.email}
                  onChange={set('email')}
                  placeholder="john@example.com"
                  style={{ width: '100%' }}
                />
              </div>
            </div>

            <div className="form-group">
              <label>Phone Number</label>
              <div className="search-input-wrap">
                <Phone size={16} className="search-icon" />
                <input
                  type="tel"
                  className="form-input"
                  required
                  value={form.phone}
                  onChange={set('phone')}
                  placeholder="+91 98765 43210"
                  style={{ width: '100%' }}
                />
              </div>
            </div>
          </div>

          <div className="form-group">
            <label>Vehicle License Plate (ANPR / RFID Tag Identifier)</label>
            <div className="search-input-wrap">
              <Car size={16} className="search-icon" />
              <input
                type="text"
                className="form-input"
                required
                value={form.vehicle_number}
                onChange={set('vehicle_number')}
                placeholder="e.g. MH12AB1234"
                style={{ width: '100%', fontFamily: 'var(--font-mono)', textTransform: 'uppercase' }}
              />
            </div>
            <span className="form-help">Used by automated barrier gates to verify access without tickets</span>
          </div>

          <div className="form-group">
            <label>Password</label>
            <div className="search-input-wrap">
              <Lock size={16} className="search-icon" />
              <input
                type="password"
                className="form-input"
                required
                minLength={6}
                value={form.password}
                onChange={set('password')}
                placeholder="Minimum 6 characters"
                style={{ width: '100%' }}
              />
            </div>
          </div>

          {error && (
            <div className="alert-banner critical" style={{ margin: '1rem 0' }}>
              <AlertTriangle size={16} />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            className="btn primary lg"
            style={{ width: '100%', marginTop: '0.5rem' }}
            disabled={loading}
          >
            {loading ? 'Creating Account...' : 'Complete Driver Registration'}
            <ArrowRight size={16} />
          </button>
        </form>

        <div style={{ textAlign: 'center', marginTop: '1.5rem', fontSize: '0.85rem' }}>
          <span className="muted">Already registered? </span>
          <Link to="/login" style={{ color: 'var(--blue-600)', fontWeight: 600, textDecoration: 'none' }}>
            Sign in
          </Link>
        </div>
      </div>
    </div>
  );
}
