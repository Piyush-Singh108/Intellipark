import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Car, Lock, Mail, ArrowRight, AlertTriangle } from 'lucide-react';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: 'driver@intellipark.com', password: 'driver123' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const user = await login(form);
      navigate(user.role === 'admin' ? '/admin' : '/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Email or password is incorrect.');
    } finally {
      setLoading(false);
    }
  };

  const fillCredentials = (email, password) => {
    setForm({ email, password });
    setError('');
  };

  return (
    <div className="auth-page-wrapper">
      <div className="auth-card">
        <div className="auth-header">
          <div
            style={{
              width: 52,
              height: 52,
              borderRadius: 'var(--radius-sm)',
              background: 'var(--blue-600)',
              color: '#fff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 1rem',
            }}
          >
            <Car size={28} />
          </div>
          <h1>Sign in to IntelliPark</h1>
          <p>Smart Parking Management &amp; Barrier Automation</p>
        </div>

        <form onSubmit={onSubmit}>
          <div className="form-group">
            <label>Email Address</label>
            <div className="search-input-wrap">
              <Mail size={16} className="search-icon" />
              <input
                type="email"
                className="form-input"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="name@domain.com"
                style={{ width: '100%' }}
              />
            </div>
          </div>

          <div className="form-group">
            <label>Password</label>
            <div className="search-input-wrap">
              <Lock size={16} className="search-icon" />
              <input
                type="password"
                className="form-input"
                required
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;"
                style={{ width: '100%' }}
              />
            </div>
          </div>

          {error && (
            <div className="alert-banner critical" style={{ margin: '1rem 0' }}>
              <AlertTriangle size={16} />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            className="btn primary lg"
            style={{ width: '100%', marginTop: '0.5rem' }}
            disabled={loading}
          >
            {loading ? 'Authenticating...' : 'Sign In'}
            <ArrowRight size={16} />
          </button>
        </form>

        {/* Demo Credentials Quick-Fill Pill */}
        <div className="auth-demo-credentials">
          <strong style={{ display: 'block', marginBottom: '0.4rem', color: 'var(--navy-900)' }}>
            Demo Evaluation Accounts (1-Click Fill):
          </strong>
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            <button
              type="button"
              className="btn secondary sm"
              style={{ fontSize: '0.75rem' }}
              onClick={() => fillCredentials('driver@intellipark.com', 'driver123')}
            >
              Driver: <code>driver@intellipark.com</code>
            </button>
            <button
              type="button"
              className="btn secondary sm"
              style={{ fontSize: '0.75rem' }}
              onClick={() => fillCredentials('admin@intellipark.com', 'admin123')}
            >
              Admin: <code>admin@intellipark.com</code>
            </button>
          </div>
        </div>

        <div style={{ textAlign: 'center', marginTop: '1.5rem', fontSize: '0.85rem' }}>
          <span className="muted">New to IntelliPark? </span>
          <Link to="/register" style={{ color: 'var(--blue-600)', fontWeight: 600, textDecoration: 'none' }}>
            Create an account
          </Link>
        </div>
      </div>
    </div>
  );
}
