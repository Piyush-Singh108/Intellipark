import { useState, useEffect } from 'react';
import {
  getVehicleLogs,
  getActiveParked,
  recordVehicleEntry,
  recordVehicleExit,
} from '../../services/entryExitService';
import Loader from '../../components/common/Loader';
import StatusBadge from '../../components/common/StatusBadge';
import { formatDateTime, formatMoney } from '../../utils/format';
import {
  DoorOpen,
  Camera,
  Radio,
  Keyboard,
  CheckCircle2,
  AlertTriangle,
  Car,
  Clock,
  ArrowRight,
  RefreshCw,
  Cpu,
} from 'lucide-react';

export default function GateTerminal() {
  const [logs, setLogs] = useState([]);
  const [activeParked, setActiveParked] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  // Mode: 'entry' or 'exit'
  const [terminalMode, setTerminalMode] = useState('entry');
  const [method, setMethod] = useState('anpr'); // 'anpr', 'rfid', 'manual'
  const [vehicleNumber, setVehicleNumber] = useState('MH12AB1234');
  const [rfidTag, setRfidTag] = useState('RFID-984210');
  const [gateName, setGateName] = useState('Gate 1 (North Entry)');

  // Simulation result
  const [actionLoading, setActionLoading] = useState(false);
  const [terminalResult, setTerminalResult] = useState(null);
  const [terminalError, setTerminalError] = useState('');

  const fetchTerminalData = async (isRefetch = false) => {
    if (isRefetch) setRefreshing(true);
    else setLoading(true);
    setError('');

    try {
      const [allLogs, parked] = await Promise.all([
        getVehicleLogs(),
        getActiveParked(),
      ]);
      setLogs(allLogs);
      setActiveParked(parked);
    } catch (err) {
      setError(err.response?.data?.message || 'Error loading gate terminal telemetry.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchTerminalData();
  }, []);

  const handleSimulateAction = async (e) => {
    e.preventDefault();
    setTerminalError('');
    setTerminalResult(null);
    setActionLoading(true);

    try {
      if (terminalMode === 'entry') {
        const res = await recordVehicleEntry({
          vehicle_number: vehicleNumber.trim().toUpperCase(),
          method,
          rfid_tag: method === 'rfid' ? rfidTag : undefined,
          gate: gateName,
        });
        setTerminalResult({
          type: 'entry',
          barrier_status: 'OPEN',
          message: res.message,
          data: res,
        });
      } else {
        // Exit
        const res = await recordVehicleExit({
          vehicle_number: vehicleNumber.trim().toUpperCase(),
          gate: 'Gate 1 (Main Exit)',
        });
        setTerminalResult({
          type: 'exit',
          barrier_status: 'OPEN',
          message: res.message,
          data: res,
        });
      }

      fetchTerminalData(true);
    } catch (err) {
      setTerminalError(err.response?.data?.message || 'Barrier operation rejected.');
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) return <Loader message="Connecting to gate barrier controller and ANPR optical scanner..." />;
  if (error) return <Loader error={error} />;

  return (
    <div>
      {/* Page Title */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.25rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
            <span className="badge active" style={{ fontSize: '0.75rem' }}>
              <Cpu size={12} /> Hardware Integration Simulator
            </span>
            <span style={{ fontSize: '0.8rem', color: 'var(--slate-400)' }}>
              Optical Character Recognition &bull; RFID Transponders &bull; Boom Barrier
            </span>
          </div>
          <h1>Smart Barrier Gate Terminal</h1>
          <p>Modular vehicle entry and departure control with simulated ANPR cameras, RFID scanners, and manual fallback.</p>
        </div>

        <button className="btn outline" onClick={() => fetchTerminalData(true)} disabled={refreshing}>
          <RefreshCw size={15} className={refreshing ? 'spinner' : ''} />
          <span>Sync Telemetry</span>
        </button>
      </div>

      {/* Demo Disclosure Alert */}
      <div className="alert-banner info" style={{ marginBottom: '1.5rem' }}>
        <DoorOpen size={20} />
        <div>
          <strong>Demonstration Mode Notice:</strong> This interactive terminal simulates real-time hardware signals from physical boom barriers, license plate optical recognition (ANPR) cameras, and 13.56 MHz RFID / FASTag readers. In production, this service receives Webhook events via MQTT or HTTP from physical gate controllers.
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '1.5rem', marginBottom: '2rem' }}>
        {/* Terminal Controls Card */}
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
            <h3>Barrier Gate Operations</h3>
            {/* Mode switch */}
            <div className="tab-pills">
              <button
                type="button"
                className={`tab-pill ${terminalMode === 'entry' ? 'active' : ''}`}
                onClick={() => {
                  setTerminalMode('entry');
                  setTerminalResult(null);
                }}
              >
                Entrance Barrier
              </button>
              <button
                type="button"
                className={`tab-pill ${terminalMode === 'exit' ? 'active' : ''}`}
                onClick={() => {
                  setTerminalMode('exit');
                  setTerminalResult(null);
                }}
              >
                Exit Barrier
              </button>
            </div>
          </div>

          <form onSubmit={handleSimulateAction}>
            {/* Recognition Method Selection */}
            <div className="form-group">
              <label>Identification Sensor Method</label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0.5rem' }}>
                <button
                  type="button"
                  className={`btn sm ${method === 'anpr' ? 'primary' : 'outline'}`}
                  onClick={() => setMethod('anpr')}
                >
                  <Camera size={13} />
                  <span>ANPR Camera</span>
                </button>
                <button
                  type="button"
                  className={`btn sm ${method === 'rfid' ? 'primary' : 'outline'}`}
                  onClick={() => setMethod('rfid')}
                >
                  <Radio size={13} />
                  <span>RFID / FastTag</span>
                </button>
                <button
                  type="button"
                  className={`btn sm ${method === 'manual' ? 'primary' : 'outline'}`}
                  onClick={() => setMethod('manual')}
                >
                  <Keyboard size={13} />
                  <span>Manual Input</span>
                </button>
              </div>
            </div>

            {/* Vehicle Number Input */}
            <div className="form-group">
              <label>Vehicle License Plate Number</label>
              <input
                type="text"
                className="form-input"
                required
                placeholder="e.g. MH12AB1234"
                value={vehicleNumber}
                onChange={(e) => setVehicleNumber(e.target.value.toUpperCase())}
                style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: '1.1rem' }}
              />
              <span className="form-help">Quick test plates: MH12AB1234, DL01CA5678, KA05MJ9876</span>
            </div>

            {/* Quick autofill buttons */}
            <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap', marginBottom: '1.15rem' }}>
              <button
                type="button"
                className="btn secondary sm"
                onClick={() => setVehicleNumber('MH12AB1234')}
              >
                Demo Driver (MH12AB1234)
              </button>
              <button
                type="button"
                className="btn secondary sm"
                onClick={() => setVehicleNumber('DL01CA5678')}
              >
                Priya (DL01CA5678)
              </button>
              <button
                type="button"
                className="btn secondary sm"
                onClick={() => setVehicleNumber('KA05MJ9876')}
              >
                Rahul (KA05MJ9876)
              </button>
            </div>

            {/* RFID Tag input if rfid selected */}
            {method === 'rfid' && (
              <div className="form-group">
                <label>FASTag / RFID Transponder UID</label>
                <input
                  type="text"
                  className="form-input"
                  value={rfidTag}
                  onChange={(e) => setRfidTag(e.target.value)}
                  style={{ fontFamily: 'var(--font-mono)' }}
                />
              </div>
            )}

            {/* Error banner */}
            {terminalError && (
              <div className="alert-banner critical" style={{ marginBottom: '1rem' }}>
                <AlertTriangle size={16} />
                <span>{terminalError}</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              className="btn primary lg"
              style={{ width: '100%' }}
              disabled={actionLoading}
            >
              {actionLoading
                ? 'Processing Barrier Signal...'
                : terminalMode === 'entry'
                ? 'Simulate Vehicle Arrival (Raise Barrier)'
                : 'Simulate Vehicle Departure (Calculate & Exit)'}
            </button>
          </form>
        </div>

        {/* Live Barrier Status & Camera View Simulation */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <h3>Barrier Gate Telemetry</h3>
              <span className={`badge ${terminalResult ? 'available' : 'maintenance'}`}>
                {terminalResult ? 'BARRIER OPEN' : 'BARRIER DOWN'}
              </span>
            </div>

            {/* Camera View Box Simulation */}
            <div
              style={{
                background: 'var(--navy-950)',
                color: '#fff',
                borderRadius: 'var(--radius-sm)',
                padding: '1.25rem',
                minHeight: '160px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                position: 'relative',
                overflow: 'hidden',
                border: '1px solid var(--navy-800)',
                marginBottom: '1rem',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: 'var(--slate-400)' }}>
                <span>[CAM-01] {gateName}</span>
                <span>REC &bull; 1080P 60FPS</span>
              </div>

              <div style={{ textAlign: 'center', margin: '1rem 0' }}>
                <div
                  style={{
                    display: 'inline-block',
                    border: '2px solid var(--emerald-500)',
                    padding: '0.4rem 1.25rem',
                    borderRadius: 4,
                    background: 'rgba(16, 185, 129, 0.1)',
                  }}
                >
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.4rem', fontWeight: 800, letterSpacing: '0.1em' }}>
                    {vehicleNumber || 'NO PLATE'}
                  </div>
                  <div style={{ fontSize: '0.65rem', color: 'var(--emerald-400)', textTransform: 'uppercase' }}>
                    ANPR OCR Confidence: {method === 'anpr' ? '98.8%' : 'N/A'}
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.7rem', color: 'var(--slate-400)' }}>
                <span>Sensors: OPTICAL + INDUCTIVE LOOP</span>
                <span>Signal: {terminalResult ? '200 OK (RELAY TRIP)' : 'AWAITING APPROACH'}</span>
              </div>
            </div>

            {/* Result Details Callout */}
            {terminalResult && (
              <div
                style={{
                  background: 'var(--emerald-50)',
                  border: '1px solid var(--emerald-200)',
                  borderRadius: 'var(--radius-sm)',
                  padding: '1rem',
                  fontSize: '0.85rem',
                  color: 'var(--emerald-800)',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 700, marginBottom: '0.35rem' }}>
                  <CheckCircle2 size={16} />
                  <span>{terminalResult.message}</span>
                </div>
                {terminalResult.type === 'entry' ? (
                  <div>
                    Allocated Bay: <strong>{terminalResult.data.slot_number}</strong> (Floor {terminalResult.data.floor}) &bull; Distance from Gate: ~{terminalResult.data.distance_from_entrance}m
                  </div>
                ) : (
                  <div>
                    Total Duration: <strong>{terminalResult.data.duration_minutes} mins</strong> &bull; Calculated Fee: <strong>{formatMoney(terminalResult.data.total_fee)}</strong> &bull; Status: {terminalResult.data.payment_status}
                  </div>
                )}
              </div>
            )}
          </div>

          <div style={{ fontSize: '0.785rem', color: 'var(--slate-500)', marginTop: '1rem' }}>
            Currently Parked Vehicles inside facility: <strong>{activeParked.length}</strong>
          </div>
        </div>
      </div>

      {/* Live Barrier Activity Logs */}
      <div className="card">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
          <h3>Live Gate Access Logs</h3>
          <span style={{ fontSize: '0.8rem', color: 'var(--slate-500)' }}>
            Showing last {logs.length} barrier events
          </span>
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Vehicle Plate</th>
                <th>Bay Number</th>
                <th>Identification Method</th>
                <th>Entry Time</th>
                <th>Exit Time</th>
                <th>Duration</th>
                <th>Fee Charged</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {logs.length === 0 ? (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '1.5rem', color: 'var(--slate-400)' }}>
                    No barrier events recorded yet.
                  </td>
                </tr>
              ) : (
                logs.map((log) => (
                  <tr key={log._id}>
                    <td>
                      <strong style={{ fontFamily: 'var(--font-mono)' }}>{log.vehicle_number}</strong>
                    </td>
                    <td>
                      <strong style={{ fontFamily: 'var(--font-mono)' }}>{log.slot?.slot_number || 'N/A'}</strong>
                      {log.slot?.floor && (
                        <span style={{ fontSize: '0.75rem', color: 'var(--slate-400)', marginLeft: 4 }}>
                          (L{log.slot.floor})
                        </span>
                      )}
                    </td>
                    <td>
                      <span style={{ textTransform: 'uppercase', fontSize: '0.75rem', fontWeight: 600 }}>
                        {log.method}
                      </span>
                    </td>
                    <td>
                      <span style={{ fontSize: '0.8rem' }}>{formatDateTime(log.entry_time)}</span>
                    </td>
                    <td>
                      <span style={{ fontSize: '0.8rem' }}>
                        {log.exit_time ? formatDateTime(log.exit_time) : <span className="muted">Parked</span>}
                      </span>
                    </td>
                    <td>
                      {log.duration_minutes ? `${log.duration_minutes} min` : '-'}
                    </td>
                    <td>
                      <strong>{formatMoney(log.total_fee || 0)}</strong>
                    </td>
                    <td>
                      <StatusBadge status={log.status === 'parked' ? 'active' : 'completed'} />
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
