import api from './api';

export const createReservation = (data) => api.post('/reservations', data).then((r) => r.data);
export const getMyReservations = () => api.get('/reservations/me').then((r) => r.data);
export const getActiveReservation = () => api.get('/reservations/active-now').then((r) => r.data);
export const getReservationById = (id) => api.get(`/reservations/${id}`).then((r) => r.data);
export const cancelReservation = (id, reason) => api.patch(`/reservations/${id}/cancel`, { reason }).then((r) => r.data);
