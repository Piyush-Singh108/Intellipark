import api from './api';

export const makePayment = (data) => api.post('/payments', data).then((r) => r.data);
export const getPaymentByReservation = (resId) => api.get(`/payments/reservation/${resId}`).then((r) => r.data);
