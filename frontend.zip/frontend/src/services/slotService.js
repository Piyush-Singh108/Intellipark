import api from './api';

export const getSlots = (params) => api.get('/slots', { params }).then((r) => r.data);
export const getAvailableSlots = () => getSlots({ status: 'available' });
export const getFloorStats = () => api.get('/slots/floors').then((r) => r.data);
export const getNearestSlot = (params) => api.get('/slots/nearest', { params }).then((r) => r.data);
export const getSlotById = (id) => api.get(`/slots/${id}`).then((r) => r.data);
