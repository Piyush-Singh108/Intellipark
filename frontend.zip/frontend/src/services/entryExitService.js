import api from './api';

export const getVehicleLogs = () => api.get('/entry-exit/logs').then((r) => r.data);
export const getActiveParked = () => api.get('/entry-exit/active').then((r) => r.data);
export const recordVehicleEntry = (data) => api.post('/entry-exit/entry', data).then((r) => r.data);
export const recordVehicleExit = (data) => api.post('/entry-exit/exit', data).then((r) => r.data);
