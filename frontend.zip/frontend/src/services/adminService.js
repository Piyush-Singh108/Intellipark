import api from './api';

export const getStats = () => api.get('/admin/stats').then((r) => r.data);
export const getReports = (days) => api.get('/admin/reports', { params: { days } }).then((r) => r.data);
export const getUsers = () => api.get('/admin/users').then((r) => r.data);
export const deleteUser = (id) => api.delete(`/admin/users/${id}`).then((r) => r.data);
export const getAllReservations = (params) => api.get('/admin/reservations', { params }).then((r) => r.data);
export const createSlot = (data) => api.post('/admin/slots', data).then((r) => r.data);
export const updateSlot = (id, data) => api.put(`/admin/slots/${id}`, data).then((r) => r.data);
export const updateSlotStatus = (id, status) => api.patch(`/admin/slots/${id}/status`, { status }).then((r) => r.data);
export const deleteSlot = (id) => api.delete(`/admin/slots/${id}`).then((r) => r.data);
