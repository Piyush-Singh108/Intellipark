export const ROLES = {
  USER: 'user',
  ADMIN: 'admin',
};

export const SLOT_STATUS = ['available', 'reserved', 'occupied', 'maintenance'];

export const SLOT_TYPES = [
  { id: 'all', label: 'All Types' },
  { id: 'standard', label: 'Standard Bay' },
  { id: 'ev_charging', label: 'EV Charging' },
  { id: 'handicapped', label: 'Accessible (Disabled)' },
  { id: 'vip', label: 'VIP Reserved' },
];

export const PAYMENT_METHODS = [
  { id: 'upi', label: 'UPI / QR (GPay, PhonePe, Paytm)' },
  { id: 'card', label: 'Credit / Debit Card' },
  { id: 'netbanking', label: 'Net Banking' },
  { id: 'cash', label: 'Cash at Counter / Gate' },
];

export const ENTRY_METHODS = [
  { id: 'manual', label: 'Manual Key-in' },
  { id: 'anpr', label: 'ANPR (Number Plate Camera)' },
  { id: 'rfid', label: 'FastTag / RFID Scanner' },
];
