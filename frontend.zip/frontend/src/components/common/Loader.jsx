import { AlertCircle } from 'lucide-react';

export default function Loader({ error, message = 'Loading data...' }) {
  if (error) {
    return (
      <div className="alert-banner critical" style={{ margin: '2rem 0' }}>
        <AlertCircle size={20} />
        <div>
          <strong>Error loading content:</strong>
          <p style={{ margin: '0.2rem 0 0', color: 'inherit' }}>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="loader-wrapper">
      <div className="spinner" />
      <p style={{ color: 'var(--slate-500)', fontSize: '0.9rem' }}>{message}</p>
    </div>
  );
}
