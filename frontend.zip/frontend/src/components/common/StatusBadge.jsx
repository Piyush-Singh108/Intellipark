import { CheckCircle2, Clock, XCircle, AlertCircle, Ban } from 'lucide-react';

export default function StatusBadge({ status }) {
  const s = (status || 'available').toLowerCase();

  const getIcon = () => {
    switch (s) {
      case 'available':
      case 'confirmed':
      case 'paid':
        return <CheckCircle2 size={13} />;
      case 'reserved':
      case 'pending':
        return <Clock size={13} />;
      case 'occupied':
        return <span className="badge-dot" />;
      case 'active':
        return <span className="badge-dot" />;
      case 'cancelled':
      case 'failed':
        return <XCircle size={13} />;
      case 'maintenance':
        return <Ban size={13} />;
      default:
        return <AlertCircle size={13} />;
    }
  };

  const getLabel = () => {
    if (s === 'paid') return 'Paid';
    if (s === 'pending') return 'Payment Pending';
    if (s === 'active') return 'Parked / Active';
    return s.charAt(0).toUpperCase() + s.slice(1);
  };

  return (
    <span className={`badge ${s}`}>
      {getIcon()}
      {getLabel()}
    </span>
  );
}
