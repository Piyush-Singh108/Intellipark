import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  Car,
  LayoutDashboard,
  CalendarCheck,
  BarChart3,
  Users,
  Layers,
  LogOut,
  Radio,
  DoorOpen,
} from 'lucide-react';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const onLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="nav-header">
      <div className="nav-container">
        {/* Brand */}
        <NavLink to="/" className="nav-brand">
          <div className="brand-badge">
            <Car size={20} />
          </div>
          <div className="nav-brand-text">
            Intelli<span>Park</span>
          </div>
        </NavLink>

        {/* Links */}
        <nav className="nav-links">
          {user?.role === 'user' && (
            <>
              <NavLink to="/dashboard" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                <LayoutDashboard size={16} />
                <span>Dashboard</span>
              </NavLink>
              <NavLink to="/slots" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                <Layers size={16} />
                <span>Find Parking</span>
              </NavLink>
              <NavLink to="/reservations" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                <CalendarCheck size={16} />
                <span>My Bookings</span>
              </NavLink>
              <NavLink to="/terminal" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                <DoorOpen size={16} />
                <span>Gate Barrier</span>
              </NavLink>
            </>
          )}

          {user?.role === 'admin' && (
            <>
              <NavLink to="/admin" end className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                <LayoutDashboard size={16} />
                <span>Operations</span>
              </NavLink>
              <NavLink to="/admin/slots" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                <Layers size={16} />
                <span>Manage Bays</span>
              </NavLink>
              <NavLink to="/admin/users" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                <Users size={16} />
                <span>Users</span>
              </NavLink>
              <NavLink to="/admin/reports" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                <BarChart3 size={16} />
                <span>Reports & BI</span>
              </NavLink>
              <NavLink to="/terminal" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                <DoorOpen size={16} />
                <span>Gate Barrier</span>
              </NavLink>
            </>
          )}
        </nav>

        {/* User Profile & Actions */}
        <div className="nav-user-section">
          {user ? (
            <>
              <div className="user-profile-pill">
                <span style={{ fontWeight: 600 }}>{user.name}</span>
                <span className={`role-tag ${user.role}`}>{user.role}</span>
              </div>
              <button className="btn outline sm" onClick={onLogout} title="Log out of system">
                <LogOut size={15} />
                <span>Sign Out</span>
              </button>
            </>
          ) : (
            <NavLink to="/login" className="btn primary sm">
              Sign In
            </NavLink>
          )}
        </div>
      </div>
    </header>
  );
}
