import StatusBadge from '../common/StatusBadge';
import { formatMoney } from '../../utils/format';
import { Zap, Accessibility, Crown, Navigation, Check } from 'lucide-react';

export default function SlotCard({ slot, onSelect, isSelected = false }) {
  const getTypePill = () => {
    switch (slot.type) {
      case 'ev_charging':
        return (
          <span className="slot-type-pill ev" title="Equipped with EV Fast Charger">
            <Zap size={11} style={{ display: 'inline', marginRight: 2 }} /> EV Fast
          </span>
        );
      case 'handicapped':
        return (
          <span className="slot-type-pill handicapped" title="Accessible Parking">
            <Accessibility size={11} style={{ display: 'inline', marginRight: 2 }} /> Accessible
          </span>
        );
      case 'vip':
        return (
          <span className="slot-type-pill vip" title="VIP Reserved">
            <Crown size={11} style={{ display: 'inline', marginRight: 2 }} /> VIP
          </span>
        );
      default:
        return <span className="slot-type-pill">Standard</span>;
    }
  };

  return (
    <div
      className={`slot-card ${slot.status} ${isSelected ? 'selected' : ''}`}
      onClick={() => slot.status === 'available' && onSelect?.(slot)}
      style={{ cursor: slot.status === 'available' ? 'pointer' : 'default' }}
    >
      <div>
        <div className="slot-card-header">
          <span className="slot-number">{slot.slot_number}</span>
          {getTypePill()}
        </div>

        <div className="slot-card-body">
          <p className="slot-location">
            {slot.lot_name} · Floor {slot.floor}
          </p>
          <div className="slot-rate">
            {formatMoney(slot.hourly_rate)} <span>/ hour</span>
          </div>

          <div className="slot-distance">
            <Navigation size={12} />
            <span>~{slot.distance_from_entrance || 10}m from entrance</span>
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '0.75rem', paddingTop: '0.75rem', borderTop: '1px solid var(--slate-100)' }}>
        <StatusBadge status={slot.status} />

        {slot.status === 'available' && (
          <button
            type="button"
            className="btn primary sm"
            onClick={(e) => {
              e.stopPropagation();
              onSelect?.(slot);
            }}
          >
            {isSelected ? (
              <>
                <Check size={14} /> Selected
              </>
            ) : (
              'Reserve'
            )}
          </button>
        )}
      </div>
    </div>
  );
}
