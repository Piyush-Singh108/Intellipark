import { formatMoney } from '../../utils/format';
import { Navigation, Zap, Accessibility, Crown } from 'lucide-react';

export default function ParkingSchematicMap({ slots = [], selectedSlot, onSelectSlot, currentFloor = 1 }) {
  // Filter slots for the current selected floor
  const floorSlots = slots.filter((s) => Number(s.floor) === Number(currentFloor));

  // Split into Row 1 and Row 2 for schematic view
  const midPoint = Math.ceil(floorSlots.length / 2);
  const row1 = floorSlots.slice(0, midPoint);
  const row2 = floorSlots.slice(midPoint);

  const getSlotIcon = (type) => {
    if (type === 'ev_charging') return <Zap size={11} color="var(--emerald-600)" />;
    if (type === 'handicapped') return <Accessibility size={11} color="var(--blue-600)" />;
    if (type === 'vip') return <Crown size={11} color="var(--amber-600)" />;
    return null;
  };

  return (
    <div className="schematic-wrapper">
      <div className="facility-entrance-banner">
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Navigation size={16} />
          <span>FACILITY ENTRANCE &amp; BARRIER GATE (FLOOR {currentFloor})</span>
        </div>
        <span style={{ fontSize: '0.75rem', opacity: 0.85 }}>Drive-in speed limit: 5 km/h</span>
      </div>

      {floorSlots.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--slate-500)' }}>
          No parking bays mapped on Floor {currentFloor}.
        </div>
      ) : (
        <div className="schematic-lanes">
          {/* North Parking Bays (Row 1) */}
          <div>
            <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--slate-400)', textTransform: 'uppercase', marginBottom: '0.5rem' }}>
              Zone A · North Parking Bays
            </div>
            <div className="schematic-row">
              {row1.map((slot) => {
                const isSelected = selectedSlot?.slot_id === slot.slot_id;
                return (
                  <button
                    key={slot.slot_id}
                    type="button"
                    className={`parking-bay-box ${slot.status} ${isSelected ? 'selected' : ''}`}
                    onClick={() => slot.status === 'available' && onSelectSlot(slot)}
                    disabled={slot.status !== 'available'}
                    title={`${slot.slot_number} (${slot.status}) - ${formatMoney(slot.hourly_rate)}/hr`}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                      <span className="bay-box-number">{slot.slot_number}</span>
                      {getSlotIcon(slot.type)}
                    </div>
                    <span className="bay-box-rate">{formatMoney(slot.hourly_rate)}</span>
                    <span style={{ fontSize: '0.65rem', textTransform: 'uppercase', fontWeight: 700, color: 'inherit' }}>
                      {slot.status}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Central Driving Lane */}
          <div className="driving-lane">
            <span>&lt;&lt;&lt; ONE-WAY TRAFFIC FLOW &lt;&lt;&lt;</span>
            <span>&bull;</span>
            <span>SPEED LIMIT 5 KM/H</span>
            <span>&bull;</span>
            <span>&gt;&gt;&gt; TO EXIT RAMP &gt;&gt;&gt;</span>
          </div>

          {/* South Parking Bays (Row 2) */}
          <div>
            <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--slate-400)', textTransform: 'uppercase', marginBottom: '0.5rem' }}>
              Zone B · South Parking Bays
            </div>
            <div className="schematic-row">
              {row2.map((slot) => {
                const isSelected = selectedSlot?.slot_id === slot.slot_id;
                return (
                  <button
                    key={slot.slot_id}
                    type="button"
                    className={`parking-bay-box ${slot.status} ${isSelected ? 'selected' : ''}`}
                    onClick={() => slot.status === 'available' && onSelectSlot(slot)}
                    disabled={slot.status !== 'available'}
                    title={`${slot.slot_number} (${slot.status}) - ${formatMoney(slot.hourly_rate)}/hr`}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                      <span className="bay-box-number">{slot.slot_number}</span>
                      {getSlotIcon(slot.type)}
                    </div>
                    <span className="bay-box-rate">{formatMoney(slot.hourly_rate)}</span>
                    <span style={{ fontSize: '0.65rem', textTransform: 'uppercase', fontWeight: 700, color: 'inherit' }}>
                      {slot.status}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Map Legend */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '1.5rem', marginTop: '1.25rem', flexWrap: 'wrap', fontSize: '0.8rem', color: 'var(--slate-600)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <span style={{ width: 12, height: 12, borderRadius: 2, background: 'var(--emerald-500)' }} />
          <span>Available</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <span style={{ width: 12, height: 12, borderRadius: 2, background: 'var(--rose-500)' }} />
          <span>Occupied</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <span style={{ width: 12, height: 12, borderRadius: 2, background: 'var(--amber-500)' }} />
          <span>Reserved</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <span style={{ width: 12, height: 12, borderRadius: 2, background: 'var(--slate-400)' }} />
          <span>Maintenance</span>
        </div>
      </div>
    </div>
  );
}
