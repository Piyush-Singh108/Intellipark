import { useNavigate } from 'react-router-dom';
import StatusBadge from '../common/StatusBadge';
import { formatDateTime, formatMoney } from '../../utils/format';
import { CreditCard, XCircle, FileText } from 'lucide-react';

export default function ReservationRow({ r, onCancel, onViewPass }) {
  const navigate = useNavigate();

  return (
    <tr>
      <td>
        <strong style={{ fontFamily: 'var(--font-mono)' }}>{r.slot_number}</strong>
        <div style={{ fontSize: '0.75rem', color: 'var(--slate-400)' }}>
          {r.lot_name || 'Main Lot'} · L{r.floor || 1}
        </div>
      </td>
      <td>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.85rem' }}>
          {r.vehicle_number || 'N/A'}
        </span>
      </td>
      <td>
        <div style={{ fontSize: '0.825rem' }}>{formatDateTime(r.start_time)}</div>
        <div style={{ fontSize: '0.75rem', color: 'var(--slate-400)' }}>to {formatDateTime(r.end_time)}</div>
      </td>
      <td>
        <strong>{formatMoney(r.amount)}</strong>
      </td>
      <td>
        <StatusBadge status={r.status} />
      </td>
      <td>
        <StatusBadge status={r.payment_status || 'pending'} />
      </td>
      <td style={{ textAlign: 'right' }}>
        <div style={{ display: 'inline-flex', gap: '0.4rem', flexWrap: 'wrap', justifyContent: 'flex-end' }}>
          {/* Pay Button */}
          {r.status === 'confirmed' && r.payment_status !== 'paid' && (
            <button
              className="btn primary sm"
              onClick={() => navigate(`/pay/${r.reservation_id}`)}
              title="Proceed to secure checkout"
            >
              <CreditCard size={13} />
              <span>Pay</span>
            </button>
          )}

          {/* View Pass / Receipt */}
          <button
            className="btn outline sm"
            onClick={() => onViewPass(r)}
            title="View booking pass and receipt"
          >
            <FileText size={13} />
            <span>Pass</span>
          </button>

          {/* Cancel button */}
          {r.status === 'confirmed' && (
            <button
              className="btn outline sm"
              style={{ color: 'var(--rose-600)' }}
              onClick={() => onCancel(r)}
              title="Cancel this reservation"
            >
              <XCircle size={13} />
              <span>Cancel</span>
            </button>
          )}
        </div>
      </td>
    </tr>
  );
}
