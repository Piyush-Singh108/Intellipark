import StatusBadge from '../common/StatusBadge';
import { SLOT_STATUS } from '../../utils/constants';
import { formatMoney } from '../../utils/format';
import { Edit2, Trash2 } from 'lucide-react';

export default function SlotTable({ slots, onStatus, onEdit, onDelete }) {
  return (
    <div className="table-card">
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Bay Number</th>
              <th>Floor</th>
              <th>Type</th>
              <th>Lot Name</th>
              <th>Rate / Hour</th>
              <th>Distance</th>
              <th>Current Status</th>
              <th>Quick Status</th>
              <th style={{ textAlign: 'right' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {slots.length === 0 ? (
              <tr>
                <td colSpan="9" style={{ textAlign: 'center', padding: '2rem', color: 'var(--slate-500)' }}>
                  No parking slots match the selected criteria.
                </td>
              </tr>
            ) : (
              slots.map((s) => (
                <tr key={s.slot_id}>
                  <td>
                    <strong style={{ fontFamily: 'var(--font-mono)', fontSize: '0.95rem' }}>{s.slot_number}</strong>
                  </td>
                  <td>Level {s.floor}</td>
                  <td>
                    <span style={{ textTransform: 'capitalize', fontSize: '0.8rem', color: 'var(--slate-600)' }}>
                      {s.type ? s.type.replace('_', ' ') : 'Standard'}
                    </span>
                  </td>
                  <td>{s.lot_name}</td>
                  <td>
                    <strong>{formatMoney(s.hourly_rate)}</strong>
                  </td>
                  <td>~{s.distance_from_entrance || 10}m</td>
                  <td>
                    <StatusBadge status={s.status} />
                  </td>
                  <td>
                    <select
                      className="form-select"
                      style={{ padding: '0.3rem 0.5rem', fontSize: '0.8rem' }}
                      value={s.status}
                      onChange={(e) => onStatus(s.slot_id, e.target.value)}
                    >
                      {SLOT_STATUS.map((st) => (
                        <option key={st} value={st}>
                          {st.charAt(0).toUpperCase() + st.slice(1)}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <div style={{ display: 'inline-flex', gap: '0.4rem' }}>
                      <button
                        className="btn outline sm"
                        onClick={() => onEdit(s)}
                        title="Edit Slot Parameters"
                      >
                        <Edit2 size={13} />
                        <span>Edit</span>
                      </button>
                      <button
                        className="btn danger sm"
                        onClick={() => onDelete(s.slot_id, s.slot_number)}
                        title="Delete slot"
                      >
                        <Trash2 size={13} />
                        <span>Delete</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
