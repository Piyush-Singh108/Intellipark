export default function StatCard({ label, value, sub, color = 'blue', icon }) {
  return (
    <div className={`stat-card ${color}`}>
      <div className="stat-card-header">
        <span className="stat-card-label">{label}</span>
        {icon && <div className={`stat-icon-wrapper ${color}`}>{icon}</div>}
      </div>
      <div className="stat-card-value">{value}</div>
      {sub && <div className="stat-card-sub">{sub}</div>}
    </div>
  );
}
