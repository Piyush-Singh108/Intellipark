# IntelliPark frontend (React + Vite)

    npm install
    npm run dev

Set the backend URL in vite.config.js (proxy) or via VITE_API_URL.

## Expected REST endpoints (mapped to DBMS tables)
| Endpoint | Tables / SQL |
|---|---|
| POST /auth/login, /auth/register | Users, Vehicles |
| GET /slots | ParkingSlots JOIN ParkingLots |
| POST /reservations | Reservations (transaction + unique/overlap check, set slot reserved) |
| GET /reservations/me | Reservations JOIN ParkingSlots LEFT JOIN Payments |
| PATCH /reservations/:id/cancel | UPDATE Reservations, free the slot (trigger) |
| POST /payments | Payments (amount = hours x hourly_rate) |
| GET /admin/stats | COUNT / SUM aggregates |
| GET /admin/reports | GROUP BY date, GROUP BY slot |
| POST/PATCH/DELETE /admin/slots | ParkingSlots CRUD |

Login response shape: { token, user: { id, name, role: 'user' | 'admin' } }
