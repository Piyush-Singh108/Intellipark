# IntelliPark backend (Express + MongoDB)

    npm install
    npm run seed     # creates demo users and 16 slots
    npm run dev      # API on http://localhost:5000

Requires MongoDB running locally (or put an Atlas URI in .env as MONGO_URI).

Collections: users, slots, reservations (refs user + slot), payments (refs reservation + user).
Logins after seeding: admin@intellipark.com / admin123 and driver@intellipark.com / driver123
