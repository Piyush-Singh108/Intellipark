import mongoose from 'mongoose';

const reservationSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  slot: { type: mongoose.Schema.Types.ObjectId, ref: 'Slot', required: true },
  vehicle_number: { type: String, uppercase: true, trim: true },
  start_time: { type: Date, required: true },
  end_time: { type: Date, required: true },
  amount: { type: Number, required: true, min: 0 },
  status: { type: String, enum: ['confirmed', 'active', 'completed', 'cancelled'], default: 'confirmed' },
  check_in_time: { type: Date },
  check_out_time: { type: Date },
  cancellation_reason: { type: String },
}, { timestamps: true });

reservationSchema.index({ slot: 1, start_time: 1, end_time: 1 });
reservationSchema.index({ user: 1, createdAt: -1 });
reservationSchema.index({ status: 1 });

export default mongoose.model('Reservation', reservationSchema);
