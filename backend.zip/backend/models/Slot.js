import mongoose from 'mongoose';

const slotSchema = new mongoose.Schema({
  slot_number: { type: String, required: true, unique: true, uppercase: true, trim: true },
  lot_name: { type: String, default: 'Main Lot', trim: true },
  floor: { type: Number, default: 1, min: 1 },
  hourly_rate: { type: Number, required: true, min: 0 },
  status: { type: String, enum: ['available', 'reserved', 'occupied', 'maintenance'], default: 'available' },
  type: { type: String, enum: ['standard', 'ev_charging', 'handicapped', 'vip'], default: 'standard' },
  distance_from_entrance: { type: Number, default: 10, min: 1 }, // in meters for nearest slot guidance
  row: { type: String, default: 'A' },
  col: { type: Number, default: 1 },
  current_vehicle: { type: String, default: null },
}, { timestamps: true });

slotSchema.index({ floor: 1, status: 1 });
slotSchema.index({ distance_from_entrance: 1 });

export default mongoose.model('Slot', slotSchema);
