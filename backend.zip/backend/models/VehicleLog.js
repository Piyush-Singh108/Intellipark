import mongoose from 'mongoose';

const vehicleLogSchema = new mongoose.Schema({
  vehicle_number: { type: String, required: true, uppercase: true, trim: true },
  slot: { type: mongoose.Schema.Types.ObjectId, ref: 'Slot' },
  reservation: { type: mongoose.Schema.Types.ObjectId, ref: 'Reservation' },
  entry_time: { type: Date, default: Date.now },
  exit_time: { type: Date },
  method: { type: String, enum: ['anpr', 'rfid', 'manual'], default: 'manual' },
  rfid_tag: { type: String, trim: true },
  confidence_score: { type: Number, default: 99.2 }, // e.g., ANPR confidence percentage
  status: { type: String, enum: ['parked', 'exited'], default: 'parked' },
  duration_minutes: { type: Number, default: 0 },
  hourly_rate: { type: Number, default: 40 },
  total_fee: { type: Number, default: 0 },
  payment_status: { type: String, enum: ['paid', 'pending', 'waived'], default: 'pending' },
  gate: { type: String, default: 'Gate 1 (North Entry)' },
  notes: { type: String },
}, { timestamps: true });

vehicleLogSchema.index({ vehicle_number: 1, status: 1 });
vehicleLogSchema.index({ entry_time: -1 });

export default mongoose.model('VehicleLog', vehicleLogSchema);
