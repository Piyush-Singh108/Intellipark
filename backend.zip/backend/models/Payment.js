import mongoose from 'mongoose';

const paymentSchema = new mongoose.Schema({
  reservation: { type: mongoose.Schema.Types.ObjectId, ref: 'Reservation', required: true, unique: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  amount: { type: Number, required: true, min: 0 },
  method: { type: String, enum: ['card', 'upi', 'netbanking', 'cash'], required: true },
  status: { type: String, enum: ['paid', 'failed', 'refunded'], default: 'paid' },
  transaction_id: { type: String, required: true, unique: true },
  gateway_provider: { type: String, default: 'IntelliPark Demo Gateway' },
  reference_notes: { type: String },
}, { timestamps: true });

paymentSchema.index({ user: 1, createdAt: -1 });
paymentSchema.index({ createdAt: -1 });

export default mongoose.model('Payment', paymentSchema);
