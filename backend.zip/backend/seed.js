import 'dotenv/config';
import bcrypt from 'bcryptjs';
import mongoose from 'mongoose';
import User from './models/User.js';
import Slot from './models/Slot.js';
import Reservation from './models/Reservation.js';
import Payment from './models/Payment.js';
import VehicleLog from './models/VehicleLog.js';

await mongoose.connect(process.env.MONGO_URI);
console.log('Connected to MongoDB. Resetting collections...');

await Promise.all([
  User.deleteMany({}),
  Slot.deleteMany({}),
  Reservation.deleteMany({}),
  Payment.deleteMany({}),
  VehicleLog.deleteMany({}),
]);

// 1. Users
const adminPassword = await bcrypt.hash('admin123', 10);
const driverPassword = await bcrypt.hash('driver123', 10);

const [adminUser, driverUser, priyaUser, rahulUser] = await User.create([
  {
    name: 'Admin Supervisor',
    email: 'admin@intellipark.com',
    phone: '+91 98765 43210',
    password: adminPassword,
    role: 'admin',
  },
  {
    name: 'Demo Driver',
    email: 'driver@intellipark.com',
    phone: '+91 98111 22233',
    password: driverPassword,
    role: 'user',
    vehicle_number: 'MH12AB1234',
  },
  {
    name: 'Priya Sharma',
    email: 'priya@example.com',
    phone: '+91 98222 33344',
    password: driverPassword,
    role: 'user',
    vehicle_number: 'DL01CA5678',
  },
  {
    name: 'Rahul Verma',
    email: 'rahul@example.com',
    phone: '+91 98333 44455',
    password: driverPassword,
    role: 'user',
    vehicle_number: 'KA05MJ9876',
  },
]);

// 2. Parking Slots across 3 Floors with real distances, zones, and types
const slotsData = [
  // Floor 1 (Ground Floor - Premium & EV charging & Accessible)
  { slot_number: 'A-01', lot_name: 'Main Lot', floor: 1, hourly_rate: 50, type: 'handicapped', distance_from_entrance: 8, row: 'A', col: 1, status: 'available' },
  { slot_number: 'A-02', lot_name: 'Main Lot', floor: 1, hourly_rate: 60, type: 'ev_charging', distance_from_entrance: 12, row: 'A', col: 2, status: 'available' },
  { slot_number: 'A-03', lot_name: 'Main Lot', floor: 1, hourly_rate: 60, type: 'ev_charging', distance_from_entrance: 14, row: 'A', col: 3, status: 'available' },
  { slot_number: 'A-04', lot_name: 'Main Lot', floor: 1, hourly_rate: 50, type: 'vip', distance_from_entrance: 16, row: 'A', col: 4, status: 'available' },
  { slot_number: 'A-05', lot_name: 'Main Lot', floor: 1, hourly_rate: 40, type: 'standard', distance_from_entrance: 18, row: 'A', col: 5, status: 'occupied', current_vehicle: 'DL01CA5678' },
  { slot_number: 'A-06', lot_name: 'Main Lot', floor: 1, hourly_rate: 40, type: 'standard', distance_from_entrance: 22, row: 'A', col: 6, status: 'available' },
  { slot_number: 'A-07', lot_name: 'Main Lot', floor: 1, hourly_rate: 40, type: 'standard', distance_from_entrance: 25, row: 'A', col: 7, status: 'maintenance' },
  { slot_number: 'A-08', lot_name: 'Main Lot', floor: 1, hourly_rate: 40, type: 'standard', distance_from_entrance: 28, row: 'A', col: 8, status: 'available' },

  // Floor 2 (Level 2 - Standard Bays)
  { slot_number: 'B-01', lot_name: 'Main Lot', floor: 2, hourly_rate: 35, type: 'standard', distance_from_entrance: 30, row: 'B', col: 1, status: 'available' },
  { slot_number: 'B-02', lot_name: 'Main Lot', floor: 2, hourly_rate: 35, type: 'standard', distance_from_entrance: 32, row: 'B', col: 2, status: 'available' },
  { slot_number: 'B-03', lot_name: 'Main Lot', floor: 2, hourly_rate: 45, type: 'ev_charging', distance_from_entrance: 35, row: 'B', col: 3, status: 'reserved' },
  { slot_number: 'B-04', lot_name: 'Main Lot', floor: 2, hourly_rate: 35, type: 'standard', distance_from_entrance: 38, row: 'B', col: 4, status: 'available' },
  { slot_number: 'B-05', lot_name: 'Main Lot', floor: 2, hourly_rate: 35, type: 'standard', distance_from_entrance: 40, row: 'B', col: 5, status: 'available' },
  { slot_number: 'B-06', lot_name: 'Main Lot', floor: 2, hourly_rate: 35, type: 'standard', distance_from_entrance: 42, row: 'B', col: 6, status: 'available' },
  { slot_number: 'B-07', lot_name: 'Main Lot', floor: 2, hourly_rate: 35, type: 'standard', distance_from_entrance: 45, row: 'B', col: 7, status: 'occupied', current_vehicle: 'KA05MJ9876' },
  { slot_number: 'B-08', lot_name: 'Main Lot', floor: 2, hourly_rate: 35, type: 'standard', distance_from_entrance: 48, row: 'B', col: 8, status: 'available' },

  // Floor 3 (Level 3 - Economy Bays)
  { slot_number: 'C-01', lot_name: 'Main Lot', floor: 3, hourly_rate: 25, type: 'standard', distance_from_entrance: 50, row: 'C', col: 1, status: 'available' },
  { slot_number: 'C-02', lot_name: 'Main Lot', floor: 3, hourly_rate: 25, type: 'standard', distance_from_entrance: 52, row: 'C', col: 2, status: 'available' },
  { slot_number: 'C-03', lot_name: 'Main Lot', floor: 3, hourly_rate: 25, type: 'standard', distance_from_entrance: 55, row: 'C', col: 3, status: 'available' },
  { slot_number: 'C-04', lot_name: 'Main Lot', floor: 3, hourly_rate: 25, type: 'standard', distance_from_entrance: 58, row: 'C', col: 4, status: 'available' },
  { slot_number: 'C-05', lot_name: 'Main Lot', floor: 3, hourly_rate: 25, type: 'standard', distance_from_entrance: 60, row: 'C', col: 5, status: 'available' },
  { slot_number: 'C-06', lot_name: 'Main Lot', floor: 3, hourly_rate: 25, type: 'standard', distance_from_entrance: 62, row: 'C', col: 6, status: 'available' },
];

const createdSlots = await Slot.insertMany(slotsData);
const slotMap = new Map(createdSlots.map((s) => [s.slot_number, s]));

// 3. Historical and Current Reservations with Payments
const now = new Date();
const yesterday = new Date(Date.now() - 24 * 3600 * 1000);
const twoDaysAgo = new Date(Date.now() - 48 * 3600 * 1000);
const tomorrow = new Date(Date.now() + 24 * 3600 * 1000);

// Reservation 1: Active today for Demo Driver (B-03)
const resActive = await Reservation.create({
  user: driverUser._id,
  slot: slotMap.get('B-03')._id,
  vehicle_number: driverUser.vehicle_number,
  start_time: new Date(now.getTime() - 30 * 60000),
  end_time: new Date(now.getTime() + 2 * 3600 * 1000),
  amount: 90,
  status: 'confirmed',
});

// Payment for Reservation 1
await Payment.create({
  reservation: resActive._id,
  user: driverUser._id,
  amount: 90,
  method: 'upi',
  status: 'paid',
  transaction_id: `TXN-PARK-${Date.now()}-1001`,
  gateway_provider: 'IntelliPark Demo Gateway (UPI AutoPay)',
  reference_notes: 'Demo driver reserved bay B-03',
});

// Reservation 2: Active park-in for Priya (A-05)
const resPriya = await Reservation.create({
  user: priyaUser._id,
  slot: slotMap.get('A-05')._id,
  vehicle_number: priyaUser.vehicle_number,
  start_time: new Date(now.getTime() - 60 * 60000),
  end_time: new Date(now.getTime() + 3 * 3600 * 1000),
  amount: 160,
  status: 'active',
  check_in_time: new Date(now.getTime() - 55 * 60000),
});

await Payment.create({
  reservation: resPriya._id,
  user: priyaUser._id,
  amount: 160,
  method: 'card',
  status: 'paid',
  transaction_id: `TXN-PARK-${Date.now()}-1002`,
  gateway_provider: 'IntelliPark Demo Gateway (Card HDFC-****4021)',
  reference_notes: 'Pre-paid 4 hours parking',
});

// Reservation 3: Past completed reservation yesterday
const resYesterday = await Reservation.create({
  user: rahulUser._id,
  slot: slotMap.get('A-02')._id,
  vehicle_number: rahulUser.vehicle_number,
  start_time: new Date(yesterday.getTime() - 4 * 3600 * 1000),
  end_time: new Date(yesterday.getTime() - 2 * 3600 * 1000),
  amount: 120,
  status: 'completed',
  check_in_time: new Date(yesterday.getTime() - 4 * 3600 * 1000),
  check_out_time: new Date(yesterday.getTime() - 2 * 3600 * 1000),
  createdAt: yesterday,
});

await Payment.create({
  reservation: resYesterday._id,
  user: rahulUser._id,
  amount: 120,
  method: 'netbanking',
  status: 'paid',
  transaction_id: `TXN-PARK-${Date.now() - 86400000}-1003`,
  gateway_provider: 'IntelliPark Demo Gateway (NetBanking SBI)',
  createdAt: yesterday,
});

// Reservation 4: 2 days ago completed
const res2Days = await Reservation.create({
  user: driverUser._id,
  slot: slotMap.get('A-01')._id,
  vehicle_number: driverUser.vehicle_number,
  start_time: new Date(twoDaysAgo.getTime() - 5 * 3600 * 1000),
  end_time: new Date(twoDaysAgo.getTime() - 2 * 3600 * 1000),
  amount: 150,
  status: 'completed',
  check_in_time: new Date(twoDaysAgo.getTime() - 5 * 3600 * 1000),
  check_out_time: new Date(twoDaysAgo.getTime() - 2 * 3600 * 1000),
  createdAt: twoDaysAgo,
});

await Payment.create({
  reservation: res2Days._id,
  user: driverUser._id,
  amount: 150,
  method: 'card',
  status: 'paid',
  transaction_id: `TXN-PARK-${Date.now() - 172800000}-1004`,
  gateway_provider: 'IntelliPark Demo Gateway (Visa Debit)',
  createdAt: twoDaysAgo,
});

// 4. Vehicle Entry/Exit Logs (ANPR & RFID demonstration records)
await VehicleLog.create([
  {
    vehicle_number: 'DL01CA5678',
    slot: slotMap.get('A-05')._id,
    reservation: resPriya._id,
    entry_time: new Date(now.getTime() - 55 * 60000),
    method: 'anpr',
    confidence_score: 99.4,
    status: 'parked',
    hourly_rate: 40,
    payment_status: 'paid',
    gate: 'Gate 1 (North Entry)',
    notes: 'ANPR camera recognition verified',
  },
  {
    vehicle_number: 'KA05MJ9876',
    slot: slotMap.get('B-07')._id,
    entry_time: new Date(now.getTime() - 40 * 60000),
    method: 'rfid',
    rfid_tag: 'RFID-984210',
    confidence_score: 100,
    status: 'parked',
    hourly_rate: 35,
    payment_status: 'pending',
    gate: 'Gate 2 (FastTag RFID Express)',
    notes: 'FastTag / RFID scanner scan auto-approved',
  },
  {
    vehicle_number: 'MH12AB1234',
    slot: slotMap.get('A-01')._id,
    reservation: res2Days._id,
    entry_time: new Date(twoDaysAgo.getTime() - 5 * 3600 * 1000),
    exit_time: new Date(twoDaysAgo.getTime() - 2 * 3600 * 1000),
    duration_minutes: 180,
    total_fee: 150,
    method: 'anpr',
    confidence_score: 98.9,
    status: 'exited',
    payment_status: 'paid',
    gate: 'Gate 1 (North Entry)',
  },
]);

console.log('Seeded successfully:');
console.log('  Admin user: admin@intellipark.com / admin123');
console.log('  Demo driver: driver@intellipark.com / driver123 (Vehicle: MH12AB1234)');
console.log('  Extra drivers: priya@example.com, rahul@example.com');
console.log(`  Parking bays: ${createdSlots.length} slots across 3 levels`);
console.log('  Sample reservations, payments, and ANPR/RFID logs populated.');

await mongoose.disconnect();
