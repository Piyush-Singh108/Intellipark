import { Router } from 'express';
import VehicleLog from '../models/VehicleLog.js';
import Slot from '../models/Slot.js';
import Reservation from '../models/Reservation.js';
import Payment from '../models/Payment.js';
import { protect } from '../middleware/auth.js';

const router = Router();
router.use(protect);

// GET /api/entry-exit/logs - barrier gate access logs
router.get('/logs', async (req, res) => {
  try {
    const logs = await VehicleLog.find()
      .populate('slot', 'slot_number floor lot_name hourly_rate')
      .populate('reservation', 'start_time end_time amount status')
      .sort('-entry_time')
      .limit(50);
    res.json(logs);
  } catch (err) {
    res.status(500).json({ message: 'Failed to retrieve vehicle logs.', error: err.message });
  }
});

// GET /api/entry-exit/active - currently parked vehicles
router.get('/active', async (req, res) => {
  try {
    const active = await VehicleLog.find({ status: 'parked' })
      .populate('slot', 'slot_number floor lot_name hourly_rate distance_from_entrance')
      .sort('-entry_time');
    res.json(active);
  } catch (err) {
    res.status(500).json({ message: 'Failed to retrieve parked vehicles.', error: err.message });
  }
});

// POST /api/entry-exit/entry - simulate ANPR / RFID / Manual barrier entry
router.post('/entry', async (req, res) => {
  try {
    const { vehicle_number, method = 'manual', rfid_tag, slot_id, gate = 'Gate 1 (Main Entrance)' } = req.body;
    if (!vehicle_number) {
      return res.status(400).json({ message: 'Vehicle license plate number is required.' });
    }

    const cleanVehicle = vehicle_number.trim().toUpperCase();

    // Check if vehicle is already logged as parked
    const alreadyParked = await VehicleLog.findOne({ vehicle_number: cleanVehicle, status: 'parked' });
    if (alreadyParked) {
      return res.status(409).json({
        message: `Vehicle ${cleanVehicle} is already recorded as inside the facility at bay ${alreadyParked.slot ? 'assigned' : 'entry'}.`,
      });
    }

    // 1. Check if vehicle has an active/confirmed reservation for today
    const now = new Date();
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999);

    let matchedReservation = await Reservation.findOne({
      vehicle_number: cleanVehicle,
      status: { $in: ['confirmed', 'active'] },
      start_time: { $lte: new Date(now.getTime() + 60 * 60 * 1000) }, // within 1h of start
      end_time: { $gte: now },
    }).populate('slot');

    let assignedSlot = null;

    if (matchedReservation && matchedReservation.slot) {
      assignedSlot = matchedReservation.slot;
      matchedReservation.status = 'active';
      matchedReservation.check_in_time = now;
      await matchedReservation.save();
    } else if (slot_id) {
      assignedSlot = await Slot.findById(slot_id);
    } else {
      // Find the nearest available slot (rule-based closest to entrance)
      assignedSlot = await Slot.findOne({ status: 'available' }).sort({ distance_from_entrance: 1, floor: 1 });
    }

    if (!assignedSlot) {
      return res.status(409).json({
        message: 'No parking bays available! Parking facility is currently at maximum capacity.',
      });
    }

    // Mark slot as occupied
    assignedSlot.status = 'occupied';
    assignedSlot.current_vehicle = cleanVehicle;
    await assignedSlot.save();

    // Check payment status on reservation if matched
    let initialPaymentStatus = 'pending';
    if (matchedReservation) {
      const existingPay = await Payment.findOne({ reservation: matchedReservation._id });
      if (existingPay && existingPay.status === 'paid') {
        initialPaymentStatus = 'paid';
      }
    }

    // Create entry log
    const log = await VehicleLog.create({
      vehicle_number: cleanVehicle,
      slot: assignedSlot._id,
      reservation: matchedReservation ? matchedReservation._id : null,
      entry_time: now,
      method,
      rfid_tag: rfid_tag || (method === 'rfid' ? `RFID-${Math.floor(100000 + Math.random() * 900000)}` : null),
      confidence_score: method === 'anpr' ? 98.7 : 100,
      status: 'parked',
      hourly_rate: assignedSlot.hourly_rate,
      payment_status: initialPaymentStatus,
      gate,
      notes: matchedReservation ? 'Pre-booked reservation verified' : 'Drive-in visitor',
    });

    res.status(201).json({
      success: true,
      barrier_status: 'OPEN',
      message: `Access granted for ${cleanVehicle}. Barrier gate opening.`,
      log_id: log._id,
      vehicle_number: cleanVehicle,
      slot_number: assignedSlot.slot_number,
      floor: assignedSlot.floor,
      lot_name: assignedSlot.lot_name,
      distance_from_entrance: assignedSlot.distance_from_entrance,
      entry_time: log.entry_time,
      method: method.toUpperCase(),
      matched_reservation: !!matchedReservation,
      is_demo_hardware_event: true,
    });
  } catch (err) {
    res.status(500).json({ message: 'Error processing vehicle entry.', error: err.message });
  }
});

// POST /api/entry-exit/exit - simulate ANPR / RFID / Manual barrier exit & fee calculation
router.post('/exit', async (req, res) => {
  try {
    const { vehicle_number, log_id, gate = 'Gate 1 (Main Exit)' } = req.body;
    if (!vehicle_number && !log_id) {
      return res.status(400).json({ message: 'Vehicle number or log ID is required.' });
    }

    const query = log_id
      ? { _id: log_id, status: 'parked' }
      : { vehicle_number: vehicle_number.trim().toUpperCase(), status: 'parked' };

    const log = await VehicleLog.findOne(query).populate('slot').populate('reservation');
    if (!log) {
      return res.status(404).json({ message: 'No active parked record found for this vehicle.' });
    }

    const exitTime = new Date();
    const durationMs = exitTime.getTime() - new Date(log.entry_time).getTime();
    const durationMinutes = Math.max(1, Math.round(durationMs / 60000));
    const durationHours = Math.max(1, Math.ceil(durationMinutes / 60));

    const rate = log.hourly_rate || log.slot?.hourly_rate || 40;
    let totalFee = durationHours * rate;

    // Check if reservation was pre-paid
    let paymentStatus = log.payment_status;
    if (log.reservation) {
      const payment = await Payment.findOne({ reservation: log.reservation._id, status: 'paid' });
      if (payment) {
        paymentStatus = 'paid';
        totalFee = payment.amount; // Pre-paid amount
      }
    }

    // Update log
    log.exit_time = exitTime;
    log.status = 'exited';
    log.duration_minutes = durationMinutes;
    log.total_fee = totalFee;
    log.payment_status = paymentStatus;
    await log.save();

    // Release slot back to available
    if (log.slot) {
      await Slot.findByIdAndUpdate(log.slot._id, {
        status: 'available',
        current_vehicle: null,
      });
    }

    // Complete reservation if linked
    if (log.reservation) {
      await Reservation.findByIdAndUpdate(log.reservation._id, {
        status: 'completed',
        check_out_time: exitTime,
      });
    }

    res.json({
      success: true,
      barrier_status: 'OPEN',
      message: `Departure logged for ${log.vehicle_number}. Barrier opening.`,
      vehicle_number: log.vehicle_number,
      slot_number: log.slot?.slot_number || 'N/A',
      entry_time: log.entry_time,
      exit_time: exitTime,
      duration_minutes: durationMinutes,
      duration_hours: durationHours,
      total_fee: totalFee,
      payment_status: paymentStatus,
      is_demo_hardware_event: true,
    });
  } catch (err) {
    res.status(500).json({ message: 'Error processing vehicle departure.', error: err.message });
  }
});

export default router;
