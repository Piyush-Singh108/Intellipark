import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';

const router = Router();

router.post('/register', async (req, res) => {
  try {
    const { name, email, phone, password, vehicle_number } = req.body;
    if (await User.findOne({ email })) return res.status(409).json({ message: 'This email is already registered.' });
    await User.create({ name, email, phone, vehicle_number, password: await bcrypt.hash(password, 10) });
    res.status(201).json({ message: 'Account created.' });
  } catch (e) { res.status(400).json({ message: e.message }); }
});

router.post('/login', async (req, res) => {
  const user = await User.findOne({ email: req.body.email?.toLowerCase() });
  if (!user || !(await bcrypt.compare(req.body.password, user.password)))
    return res.status(401).json({ message: 'Email or password is incorrect.' });
  const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1d' });
  res.json({ token, user: { id: user._id, name: user.name, role: user.role } });
});

export default router;
