import { Router } from 'express';
import Slot from '../models/Slot.js';
import { protect } from '../middleware/auth.js';

export const toSlot = (s) => ({
  slot_id: s._id,
  slot_number: s.slot_number,
  lot_name: s.lot_name || 'Main Lot',
  floor: s.floor || 1,
  hourly_rate: s.hourly_rate,
  status: s.status,
  type: s.type || 'standard',
  distance_from_entrance: s.distance_from_entrance || 10,
  row: s.row || 'A',
  col: s.col || 1,
  current_vehicle: s.current_vehicle || null,
  created_at: s.createdAt,
});

const router = Router();

// GET /api/slots - list slots with filtering and sorting
router.get('/', protect, async (req, res) => {
  try {
    const filter = {};
    if (req.query.status) filter.status = req.query.status;
    if (req.query.floor) filter.floor = Number(req.query.floor);
    if (req.query.type) filter.type = req.query.type;
    if (req.query.lot_name) filter.lot_name = req.query.lot_name;
    if (req.query.search) {
      filter.$or = [
        { slot_number: { $regex: req.query.search, $options: 'i' } },
        { lot_name: { $regex: req.query.search, $options: 'i' } },
      ];
    }
    if (req.query.min_price || req.query.max_price) {
      filter.hourly_rate = {};
      if (req.query.min_price) filter.hourly_rate.$gte = Number(req.query.min_price);
      if (req.query.max_price) filter.hourly_rate.$lte = Number(req.query.max_price);
    }

    let sortOption = { floor: 1, slot_number: 1 };
    if (req.query.sort === 'price_asc') sortOption = { hourly_rate: 1, slot_number: 1 };
    else if (req.query.sort === 'price_desc') sortOption = { hourly_rate: -1, slot_number: 1 };
    else if (req.query.sort === 'slot_asc') sortOption = { slot_number: 1 };
    else if (req.query.sort === 'distance') sortOption = { distance_from_entrance: 1, slot_number: 1 };

    const slots = await Slot.find(filter).sort(sortOption);
    res.json(slots.map(toSlot));
  } catch (err) {
    res.status(500).json({ message: 'Error retrieving parking slots.', error: err.message });
  }
});

// GET /api/slots/floors - floor-level availability aggregation
router.get('/floors', protect, async (req, res) => {
  try {
    const floorStats = await Slot.aggregate([
      {
        $group: {
          _id: '$floor',
          total: { $sum: 1 },
          available: { $sum: { $cond: [{ $eq: ['$status', 'available'] }, 1, 0] } },
          occupied: { $sum: { $cond: [{ $eq: ['$status', 'occupied'] }, 1, 0] } },
          reserved: { $sum: { $cond: [{ $eq: ['$status', 'reserved'] }, 1, 0] } },
          maintenance: { $sum: { $cond: [{ $eq: ['$status', 'maintenance'] }, 1, 0] } },
          min_rate: { $min: '$hourly_rate' },
        },
      },
      { $sort: { _id: 1 } },
      {
        $project: {
          _id: 0,
          floor: '$_id',
          total: 1,
          available: 1,
          occupied: 1,
          reserved: 1,
          maintenance: 1,
          min_rate: 1,
        },
      },
    ]);
    res.json(floorStats);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch floor statistics.', error: err.message });
  }
});

// GET /api/slots/nearest - rule-based nearest available slot recommendation
router.get('/nearest', protect, async (req, res) => {
  try {
    const filter = { status: 'available' };
    if (req.query.floor) filter.floor = Number(req.query.floor);
    if (req.query.type) filter.type = req.query.type;

    // Find available slots sorted primarily by distance_from_entrance, then floor, then slot number
    const nearestSlot = await Slot.findOne(filter).sort({ distance_from_entrance: 1, floor: 1, slot_number: 1 });

    if (!nearestSlot) {
      return res.status(404).json({ message: 'No available parking slots found matching your criteria.' });
    }

    res.json({
      recommended_slot: toSlot(nearestSlot),
      rationale: `Slot ${nearestSlot.slot_number} on Level ${nearestSlot.floor} is closest to the facility entrance (~${nearestSlot.distance_from_entrance}m walking distance).`,
      distance_meters: nearestSlot.distance_from_entrance,
    });
  } catch (err) {
    res.status(500).json({ message: 'Error determining nearest slot.', error: err.message });
  }
});

// GET /api/slots/:id - single slot lookup
router.get('/:id', protect, async (req, res) => {
  try {
    const slot = await Slot.findById(req.params.id);
    if (!slot) return res.status(404).json({ message: 'Slot not found.' });
    res.json(toSlot(slot));
  } catch (err) {
    res.status(400).json({ message: 'Invalid slot identifier.' });
  }
});

export default router;
