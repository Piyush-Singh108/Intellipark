import { Router } from 'express';
import Slot from '../models/Slot.js';
import User from '../models/User.js';
import Payment from '../models/Payment.js';
import Reservation from '../models/Reservation.js';
import { protect, adminOnly } from '../middleware/auth.js';

const router = Router();
router.use(protect, adminOnly);

// GET /api/admin/stats - real-time operational dashboard stats & alerts
router.get('/stats', async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [
      total_slots,
      available,
      occupied,
      reserved,
      maintenance,
      total_users,
      todayRev,
      totalRev,
      activeReservationsCount,
      recentReservations,
      recentPayments,
    ] = await Promise.all([
      Slot.countDocuments(),
      Slot.countDocuments({ status: 'available' }),
      Slot.countDocuments({ status: 'occupied' }),
      Slot.countDocuments({ status: 'reserved' }),
      Slot.countDocuments({ status: 'maintenance' }),
      User.countDocuments({ role: 'user' }),
      Payment.aggregate([
        { $match: { status: 'paid', createdAt: { $gte: today } } },
        { $group: { _id: null, total: { $sum: '$amount' } } },
      ]),
      Payment.aggregate([
        { $match: { status: 'paid' } },
        { $group: { _id: null, total: { $sum: '$amount' } } },
      ]),
      Reservation.countDocuments({ status: { $in: ['confirmed', 'active'] } }),
      Reservation.find()
        .populate('user', 'name email phone vehicle_number')
        .populate('slot', 'slot_number floor lot_name hourly_rate')
        .sort('-createdAt')
        .limit(6),
      Payment.find({ status: 'paid' })
        .populate('user', 'name email')
        .populate({
          path: 'reservation',
          populate: { path: 'slot', select: 'slot_number' },
        })
        .sort('-createdAt')
        .limit(6),
    ]);

    const occupancyRate = total_slots > 0 ? Math.round(((total_slots - available) / total_slots) * 100) : 0;

    // Build smart parking availability alerts
    const alerts = [];
    if (total_slots > 0 && available === 0) {
      alerts.push({ level: 'critical', message: 'Parking facility is 100% full. All bays occupied or reserved.' });
    } else if (total_slots > 0 && available <= 3) {
      alerts.push({ level: 'warning', message: `High occupancy warning: Only ${available} parking bays currently available.` });
    }

    if (maintenance > 0) {
      alerts.push({ level: 'info', message: `${maintenance} parking ${maintenance === 1 ? 'bay is' : 'bays are'} undergoing scheduled maintenance.` });
    }

    res.json({
      total_slots,
      available,
      occupied,
      reserved,
      maintenance,
      occupancy_rate: occupancyRate,
      total_users,
      revenue_today: todayRev[0]?.total || 0,
      revenue_all_time: totalRev[0]?.total || 0,
      active_reservations: activeReservationsCount,
      alerts,
      recent_reservations: recentReservations,
      recent_payments: recentPayments,
    });
  } catch (err) {
    res.status(500).json({ message: 'Error loading admin dashboard statistics.', error: err.message });
  }
});

// GET /api/admin/reports - advanced aggregation pipelines for visual analytics & charts
router.get('/reports', async (req, res) => {
  try {
    const { days = 14 } = req.query;
    const sinceDate = new Date();
    sinceDate.setDate(sinceDate.getDate() - Number(days));
    sinceDate.setHours(0, 0, 0, 0);

    const [daily, top_slots, floor_utilization, status_distribution] = await Promise.all([
      // 1. Daily revenue and booking count
      Payment.aggregate([
        { $match: { status: 'paid', createdAt: { $gte: sinceDate } } },
        {
          $group: {
            _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
            reservations: { $sum: 1 },
            revenue: { $sum: '$amount' },
          },
        },
        { $sort: { _id: 1 } },
        { $project: { _id: 0, date: '$_id', reservations: 1, revenue: 1 } },
      ]),

      // 2. Most frequently booked parking slots
      Reservation.aggregate([
        { $match: { status: { $ne: 'cancelled' } } },
        { $group: { _id: '$slot', bookings: { $sum: 1 }, total_revenue: { $sum: '$amount' } } },
        { $sort: { bookings: -1 } },
        { $limit: 8 },
        { $lookup: { from: 'slots', localField: '_id', foreignField: '_id', as: 'slot' } },
        { $unwind: '$slot' },
        {
          $project: {
            _id: 0,
            slot_id: '$slot._id',
            slot_number: '$slot.slot_number',
            floor: '$slot.floor',
            hourly_rate: '$slot.hourly_rate',
            bookings: 1,
            total_revenue: 1,
          },
        },
      ]),

      // 3. Utilization by floor
      Slot.aggregate([
        {
          $group: {
            _id: '$floor',
            total: { $sum: 1 },
            available: { $sum: { $cond: [{ $eq: ['$status', 'available'] }, 1, 0] } },
            occupied: { $sum: { $cond: [{ $eq: ['$status', 'occupied'] }, 1, 0] } },
            reserved: { $sum: { $cond: [{ $eq: ['$status', 'reserved'] }, 1, 0] } },
            maintenance: { $sum: { $cond: [{ $eq: ['$status', 'maintenance'] }, 1, 0] } },
          },
        },
        { $sort: { _id: 1 } },
        {
          $project: {
            _id: 0,
            floor: '$_id',
            total: 1,
            available: 1,
            occupied: 1,
            reserved: 1,
            maintenance: 1,
            utilization_rate: {
              $multiply: [
                { $divide: [{ $subtract: ['$total', '$available'] }, '$total'] },
                100,
              ],
            },
          },
        },
      ]),

      // 4. Overall status distribution
      Slot.aggregate([
        { $group: { _id: '$status', count: { $sum: 1 } } },
        { $project: { _id: 0, status: '$_id', count: 1 } },
      ]),
    ]);

    res.json({ daily, top_slots, floor_utilization, status_distribution });
  } catch (err) {
    res.status(500).json({ message: 'Error generating analytics reports.', error: err.message });
  }
});

// GET /api/admin/users - list users with reservation count
router.get('/users', async (req, res) => {
  try {
    const users = await User.find({ role: 'user' }).select('-password').sort('-createdAt');

    // Attach reservation counts via aggregation
    const resCounts = await Reservation.aggregate([
      { $group: { _id: '$user', count: { $sum: 1 }, total_spent: { $sum: '$amount' } } },
    ]);
    const resMap = new Map(resCounts.map((c) => [String(c._id), c]));

    const result = users.map((u) => {
      const stats = resMap.get(String(u._id)) || { count: 0, total_spent: 0 };
      return {
        _id: u._id,
        name: u.name,
        email: u.email,
        phone: u.phone || 'N/A',
        vehicle_number: u.vehicle_number || 'N/A',
        created_at: u.createdAt,
        total_reservations: stats.count,
        total_spent: stats.total_spent,
      };
    });

    res.json(result);
  } catch (err) {
    res.status(500).json({ message: 'Failed to retrieve users list.', error: err.message });
  }
});

// DELETE /api/admin/users/:id - safe user deletion with referential integrity
router.delete('/users/:id', async (req, res) => {
  try {
    const targetUser = await User.findById(req.params.id);
    if (!targetUser) {
      return res.status(404).json({ message: 'User not found.' });
    }
    if (targetUser.role === 'admin') {
      return res.status(403).json({ message: 'Administrative accounts cannot be deleted.' });
    }

    // Check for active or confirmed reservations
    const activeBooking = await Reservation.findOne({
      user: targetUser._id,
      status: { $in: ['confirmed', 'active'] },
    });
    if (activeBooking) {
      return res.status(409).json({
        message: 'Cannot delete user with active or confirmed parking reservations.',
      });
    }

    await User.findByIdAndDelete(req.params.id);
    res.json({ message: `User "${targetUser.name}" has been deleted successfully.` });
  } catch (err) {
    res.status(500).json({ message: 'Error deleting user.', error: err.message });
  }
});

// GET /api/admin/reservations - list all reservations with search & filter
router.get('/reservations', async (req, res) => {
  try {
    const filter = {};
    if (req.query.status && req.query.status !== 'all') {
      filter.status = req.query.status;
    }

    const reservations = await Reservation.find(filter)
      .populate('user', 'name email phone vehicle_number')
      .populate('slot', 'slot_number floor lot_name hourly_rate')
      .sort('-createdAt')
      .limit(100);

    const reservationIds = reservations.map((r) => r._id);
    const payments = await Payment.find({ reservation: { $in: reservationIds } });
    const paymentMap = new Map(payments.map((p) => [String(p.reservation), p]));

    const response = reservations.map((r) => {
      const p = paymentMap.get(String(r._id));
      return {
        _id: r._id,
        user_name: r.user?.name || 'Unknown',
        user_email: r.user?.email || 'N/A',
        vehicle_number: r.vehicle_number || r.user?.vehicle_number || 'N/A',
        slot_number: r.slot?.slot_number || 'Deleted Slot',
        floor: r.slot?.floor || 1,
        start_time: r.start_time,
        end_time: r.end_time,
        amount: r.amount,
        status: r.status,
        payment_status: p ? p.status : 'pending',
        transaction_id: p?.transaction_id || null,
        created_at: r.createdAt,
      };
    });

    res.json(response);
  } catch (err) {
    res.status(500).json({ message: 'Failed to retrieve reservations.', error: err.message });
  }
});

// POST /api/admin/slots - create slot with validation
router.post('/slots', async (req, res) => {
  try {
    const { slot_number, hourly_rate, lot_name, floor, type, distance_from_entrance } = req.body;
    if (!slot_number || hourly_rate === undefined) {
      return res.status(400).json({ message: 'Slot number and hourly rate are required.' });
    }

    const cleanSlotNumber = slot_number.trim().toUpperCase();
    const existing = await Slot.findOne({ slot_number: cleanSlotNumber });
    if (existing) {
      return res.status(409).json({ message: `Slot number "${cleanSlotNumber}" already exists.` });
    }

    const slot = await Slot.create({
      slot_number: cleanSlotNumber,
      hourly_rate: Number(hourly_rate),
      lot_name: (lot_name || 'Main Lot').trim(),
      floor: Number(floor || 1),
      type: type || 'standard',
      distance_from_entrance: Number(distance_from_entrance || 15),
    });

    res.status(201).json(slot);
  } catch (e) {
    res.status(400).json({ message: e.code === 11000 ? 'That slot number already exists.' : e.message });
  }
});

// PUT /api/admin/slots/:id - edit existing slot details
router.put('/slots/:id', async (req, res) => {
  try {
    const { slot_number, hourly_rate, lot_name, floor, type, distance_from_entrance, status } = req.body;
    const slot = await Slot.findById(req.params.id);
    if (!slot) return res.status(404).json({ message: 'Slot not found.' });

    if (slot_number && slot_number.trim().toUpperCase() !== slot.slot_number) {
      const clash = await Slot.findOne({ slot_number: slot_number.trim().toUpperCase() });
      if (clash) return res.status(409).json({ message: `Slot number "${slot_number}" already in use.` });
      slot.slot_number = slot_number.trim().toUpperCase();
    }

    if (hourly_rate !== undefined) slot.hourly_rate = Number(hourly_rate);
    if (lot_name) slot.lot_name = lot_name.trim();
    if (floor !== undefined) slot.floor = Number(floor);
    if (type) slot.type = type;
    if (distance_from_entrance !== undefined) slot.distance_from_entrance = Number(distance_from_entrance);
    if (status) slot.status = status;

    await slot.save();
    res.json(slot);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PATCH /api/admin/slots/:id/status - quick status update
router.patch('/slots/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const slot = await Slot.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true, runValidators: true }
    );
    if (!slot) return res.status(404).json({ message: 'Slot not found.' });
    res.json(slot);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE /api/admin/slots/:id - safe slot deletion with referential integrity check
router.delete('/slots/:id', async (req, res) => {
  try {
    const slot = await Slot.findById(req.params.id);
    if (!slot) return res.status(404).json({ message: 'Slot not found.' });

    // Referential integrity: cannot delete slot if active or confirmed reservations exist
    const hasActiveReservations = await Reservation.findOne({
      slot: slot._id,
      status: { $in: ['confirmed', 'active'] },
    });

    if (hasActiveReservations) {
      return res.status(409).json({
        message: `Cannot delete slot "${slot.slot_number}" because it has active or upcoming confirmed reservations. Please cancel those reservations first or set the slot to "maintenance".`,
      });
    }

    await Slot.findByIdAndDelete(req.params.id);
    res.json({ message: `Slot "${slot.slot_number}" deleted successfully.` });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete slot.', error: err.message });
  }
});

export default router;
