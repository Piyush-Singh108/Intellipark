import { Router } from 'express';
import Payment from '../models/Payment.js';
import Reservation from '../models/Reservation.js';
import { protect } from '../middleware/auth.js';

const router = Router();
router.use(protect);

// POST /api/payments - process payment with duplicate protection and receipt generation
router.post('/', async (req, res) => {
  try {
    const { reservation_id, method, card_details, upi_id } = req.body;
    if (!reservation_id || !method) {
      return res.status(400).json({ message: 'Reservation ID and payment method are required.' });
    }

    const r = await Reservation.findOne({ _id: reservation_id, user: req.user.id });
    if (!r) {
      return res.status(404).json({ message: 'Reservation not found.' });
    }

    if (r.status === 'cancelled') {
      return res.status(400).json({ message: 'Cannot pay for a cancelled reservation.' });
    }

    // Check duplicate payment
    const existingPayment = await Payment.findOne({ reservation: r._id });
    if (existingPayment && existingPayment.status === 'paid') {
      return res.status(409).json({
        message: 'This reservation is already paid.',
        payment_id: existingPayment._id,
        transaction_id: existingPayment.transaction_id,
      });
    }

    // Generate unique verifiable transaction reference
    const transactionId = `TXN-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

    let referenceNotes = `Processed via IntelliPark Simulated Gateway (${method.toUpperCase()})`;
    if (method === 'upi' && upi_id) {
      referenceNotes += ` · VPA: ${upi_id}`;
    } else if (method === 'card' && card_details?.last4) {
      referenceNotes += ` · Card ending in ${card_details.last4}`;
    }

    const payment = await Payment.create({
      reservation: r._id,
      user: req.user.id,
      amount: r.amount,
      method,
      status: 'paid',
      transaction_id: transactionId,
      gateway_provider: 'IntelliPark Simulated Gateway (College DBMS Demo)',
      reference_notes: referenceNotes,
    });

    res.status(201).json({
      message: 'Payment completed successfully.',
      payment_id: payment._id,
      transaction_id: payment.transaction_id,
      amount: payment.amount,
      method: payment.method,
      status: payment.status,
      timestamp: payment.createdAt,
      gateway_provider: payment.gateway_provider,
    });
  } catch (err) {
    res.status(500).json({ message: 'Payment processing error.', error: err.message });
  }
});

// GET /api/payments/reservation/:resId - retrieve payment receipt by reservation ID
router.get('/reservation/:resId', async (req, res) => {
  try {
    const payment = await Payment.findOne({ reservation: req.params.resId })
      .populate('reservation')
      .populate('user', 'name email phone vehicle_number');

    if (!payment) {
      return res.status(404).json({ message: 'No payment record found for this reservation.' });
    }

    res.json(payment);
  } catch (err) {
    res.status(400).json({ message: 'Error retrieving payment record.', error: err.message });
  }
});

export default router;
