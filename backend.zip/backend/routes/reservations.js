import { Router } from 'express';
import Reservation from '../models/Reservation.js';
import Slot from '../models/Slot.js';
import Payment from '../models/Payment.js';
import User from '../models/User.js';
import { protect } from '../middleware/auth.js';

const router = Router();
router.use(protect);

// POST /api/reservations - create reservation with clash prevention & fee calculation
router.post('/', async (req, res) => {
  try {
    const { slot_id, start_time, end_time, vehicle_number } = req.body;
    if (!slot_id || !start_time || !end_time) {
      return res.status(400).json({ message: 'Slot, start time, and end time are required.' });
    }

    const start = new Date(start_time);
    const end = new Date(end_time);

    // Validation
    const now = new Date(Date.now() - 2 * 60000); // 2-minute skew tolerance
    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      return res.status(400).json({ message: 'Invalid start or end date format.' });
    }
    if (start < now) {
      return res.status(400).json({ message: 'Start time must be in the future.' });
    }
    if (end <= start) {
      return res.status(400).json({ message: 'End time must be after the start time.' });
    }

    const durationMinutes = (end - start) / (1000 * 60);
    if (durationMinutes < 30) {
      return res.status(400).json({ message: 'Minimum reservation duration is 30 minutes.' });
    }

    const slot = await Slot.findById(slot_id);
    if (!slot) {
      return res.status(404).json({ message: 'Parking slot not found.' });
    }
    if (slot.status === 'maintenance') {
      return res.status(409).json({ message: 'This slot is currently under maintenance.' });
    }

    // Atomic clash check: find any confirmed or active reservation overlapping with requested interval
    const clash = await Reservation.findOne({
      slot: slot._id,
      status: { $in: ['confirmed', 'active'] },
      start_time: { $lt: end },
      end_time: { $gt: start },
    });

    if (clash) {
      return res.status(409).json({
        message: `Slot ${slot.slot_number} is already reserved for the chosen time interval (${new Date(clash.start_time).toLocaleTimeString()} - ${new Date(clash.end_time).toLocaleTimeString()}). Please choose another slot or time.`,
      });
    }

    // Fetch user's vehicle number if not explicitly specified
    let vehicleNum = vehicle_number;
    if (!vehicleNum) {
      const user = await User.findById(req.user.id);
      vehicleNum = user?.vehicle_number || 'UNKNOWN';
    }

    const durationHours = Math.max(1, Math.ceil(durationMinutes / 60));
    const amount = durationHours * slot.hourly_rate;

    const reservation = await Reservation.create({
      user: req.user.id,
      slot: slot._id,
      vehicle_number: vehicleNum.toUpperCase().trim(),
      start_time: start,
      end_time: end,
      amount,
      status: 'confirmed',
    });

    // If reservation is starting within the next 30 minutes, mark slot as reserved
    const isImminent = start.getTime() - Date.now() <= 30 * 60 * 1000;
    if (isImminent && slot.status === 'available') {
      slot.status = 'reserved';
      await slot.save();
    }

    res.status(201).json({
      message: 'Reservation created successfully.',
      reservation_id: reservation._id,
      slot_number: slot.slot_number,
      duration_hours: durationHours,
      amount: reservation.amount,
      start_time: reservation.start_time,
      end_time: reservation.end_time,
    });
  } catch (err) {
    res.status(500).json({ message: 'Failed to create reservation.', error: err.message });
  }
});

// GET /api/reservations/me - list reservations for logged-in user with populated slot and payment
router.get('/me', async (req, res) => {
  try {
    const list = await Reservation.find({ user: req.user.id })
      .populate('slot')
      .sort('-createdAt');

    const reservationIds = list.map((r) => r._id);
    const payments = await Payment.find({ reservation: { $in: reservationIds } });
    const paymentMap = new Map(payments.map((p) => [String(p.reservation), p]));

    const response = list.map((r) => {
      const p = paymentMap.get(String(r._id));
      return {
        reservation_id: r._id,
        slot_id: r.slot?._id,
        slot_number: r.slot?.slot_number || 'Unknown',
        lot_name: r.slot?.lot_name || 'Main Lot',
        floor: r.slot?.floor || 1,
        slot_type: r.slot?.type || 'standard',
        vehicle_number: r.vehicle_number,
        start_time: r.start_time,
        end_time: r.end_time,
        amount: r.amount,
        status: r.status,
        check_in_time: r.check_in_time,
        check_out_time: r.check_out_time,
        created_at: r.createdAt,
        payment_status: p ? p.status : 'pending',
        transaction_id: p?.transaction_id || null,
        payment_method: p?.method || null,
      };
    });

    res.json(response);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch reservations.', error: err.message });
  }
});

// GET /api/reservations/active-now - get user's current or upcoming active reservation
router.get('/active-now', async (req, res) => {
  try {
    const now = new Date();
    // Look for active reservation or confirmed reservation for today
    const active = await Reservation.findOne({
      user: req.user.id,
      status: { $in: ['confirmed', 'active'] },
      end_time: { $gte: now },
    })
      .populate('slot')
      .sort('start_time');

    if (!active) {
      return res.json({ active_reservation: null });
    }

    const payment = await Payment.findOne({ reservation: active._id });

    res.json({
      active_reservation: {
        reservation_id: active._id,
        slot_id: active.slot?._id,
        slot_number: active.slot?.slot_number,
        floor: active.slot?.floor,
        lot_name: active.slot?.lot_name,
        slot_type: active.slot?.type,
        distance_from_entrance: active.slot?.distance_from_entrance,
        vehicle_number: active.vehicle_number,
        start_time: active.start_time,
        end_time: active.end_time,
        amount: active.amount,
        status: active.status,
        payment_status: payment?.status || 'pending',
        transaction_id: payment?.transaction_id || null,
      },
    });
  } catch (err) {
    res.status(500).json({ message: 'Error retrieving active reservation.', error: err.message });
  }
});

// GET /api/reservations/:id - single reservation details with slot and payment info
router.get('/:id', async (req, res) => {
  try {
    const r = await Reservation.findOne({ _id: req.params.id, user: req.user.id }).populate('slot');
    if (!r) return res.status(404).json({ message: 'Reservation not found.' });

    const payment = await Payment.findOne({ reservation: r._id });

    const durationMinutes = Math.max(30, Math.round((new Date(r.end_time) - new Date(r.start_time)) / 60000));
    const durationHours = Math.max(1, Math.ceil(durationMinutes / 60));

    res.json({
      reservation_id: r._id,
      slot_id: r.slot?._id,
      slot_number: r.slot?.slot_number,
      lot_name: r.slot?.lot_name,
      floor: r.slot?.floor,
      hourly_rate: r.slot?.hourly_rate,
      slot_type: r.slot?.type,
      distance_from_entrance: r.slot?.distance_from_entrance,
      vehicle_number: r.vehicle_number,
      start_time: r.start_time,
      end_time: r.end_time,
      duration_hours: durationHours,
      amount: r.amount,
      status: r.status,
      created_at: r.createdAt,
      payment_status: payment ? payment.status : 'pending',
      transaction_id: payment?.transaction_id || null,
      payment_method: payment?.method || null,
      gateway_provider: payment?.gateway_provider || 'IntelliPark Demo Gateway',
    });
  } catch (err) {
    res.status(400).json({ message: 'Invalid reservation identifier.' });
  }
});

// PATCH /api/reservations/:id/cancel - cancel an eligible reservation
router.patch('/:id/cancel', async (req, res) => {
  try {
    const r = await Reservation.findOne({ _id: req.params.id, user: req.user.id });
    if (!r) {
      return res.status(404).json({ message: 'Reservation not found.' });
    }
    if (r.status === 'cancelled') {
      return res.status(400).json({ message: 'This reservation is already cancelled.' });
    }
    if (r.status === 'completed') {
      return res.status(400).json({ message: 'Completed reservations cannot be cancelled.' });
    }

    r.status = 'cancelled';
    r.cancellation_reason = req.body.reason || 'Cancelled by user';
    await r.save();

    // Release slot back to available if slot was marked reserved
    const slot = await Slot.findById(r.slot);
    if (slot && (slot.status === 'reserved' || slot.status === 'occupied')) {
      // Check if another active booking exists right now
      const otherActive = await Reservation.findOne({
        slot: slot._id,
        _id: { $ne: r._id },
        status: { $in: ['confirmed', 'active'] },
        start_time: { $lte: new Date() },
        end_time: { $gte: new Date() },
      });
      if (!otherActive) {
        slot.status = 'available';
        slot.current_vehicle = null;
        await slot.save();
      }
    }

    // Check if paid, update note
    const payment = await Payment.findOne({ reservation: r._id });
    let refundNote = '';
    if (payment && payment.status === 'paid') {
      refundNote = ' Simulated refund initiated to original payment source.';
    }

    res.json({ message: `Reservation cancelled successfully.${refundNote}` });
  } catch (err) {
    res.status(500).json({ message: 'Failed to cancel reservation.', error: err.message });
  }
});

export default router;
