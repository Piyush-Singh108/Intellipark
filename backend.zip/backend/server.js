import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import connectDB from './config/db.js';
import authRoutes from './routes/auth.js';
import slotRoutes from './routes/slots.js';
import reservationRoutes from './routes/reservations.js';
import paymentRoutes from './routes/payments.js';
import adminRoutes from './routes/admin.js';
import entryExitRoutes from './routes/entryExit.js';

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => res.json({ status: 'ok', name: 'IntelliPark Smart Parking API', time: new Date() }));
app.use('/api/auth', authRoutes);
app.use('/api/slots', slotRoutes);
app.use('/api/reservations', reservationRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/entry-exit', entryExitRoutes);

// Error handler middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Internal server error occurred.', error: err.message });
});

await connectDB();
app.listen(process.env.PORT || 5000, () => console.log(`API running on port ${process.env.PORT || 5000}`));

