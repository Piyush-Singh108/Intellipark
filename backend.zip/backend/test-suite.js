import 'dotenv/config';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from './models/User.js';
import Slot from './models/Slot.js';
import Reservation from './models/Reservation.js';
import Payment from './models/Payment.js';
import VehicleLog from './models/VehicleLog.js';

console.log('--- STARTING INTELLIPARK AUTOMATED VERIFICATION SUITE ---');

await mongoose.connect(process.env.MONGO_URI);
console.log('✓ Connected to MongoDB');

let testPassed = 0;
let testFailed = 0;

function assert(condition, testName) {
  if (condition) {
    console.log(`✓ PASS: ${testName}`);
    testPassed++;
  } else {
    console.error(`✗ FAIL: ${testName}`);
    testFailed++;
  }
}

try {
  // Test 1: User & Auth
  const driver = await User.findOne({ email: 'driver@intellipark.com' });
  assert(driver && driver.role === 'user', 'Demo Driver user exists in database');

  const admin = await User.findOne({ email: 'admin@intellipark.com' });
  assert(admin && admin.role === 'admin', 'Admin user exists in database');

  const isPasswordValid = await bcrypt.compare('driver123', driver.password);
  assert(isPasswordValid, 'Bcrypt password comparison works accurately');

  // Test 2: Slots & Nearest Slot Query
  const allSlots = await Slot.find();
  assert(allSlots.length >= 16, `Found ${allSlots.length} slots in database`);

  const availableSlots = await Slot.find({ status: 'available' }).sort({ distance_from_entrance: 1 });
  assert(availableSlots.length > 0, 'Available slots exist');

  const nearestSlot = availableSlots[0];
  assert(nearestSlot.distance_from_entrance > 0, `Nearest slot is ${nearestSlot.slot_number} at ${nearestSlot.distance_from_entrance}m`);

  // Test 3: Floor aggregation
  const floorStats = await Slot.aggregate([
    {
      $group: {
        _id: '$floor',
        total: { $sum: 1 },
        available: { $sum: { $cond: [{ $eq: ['$status', 'available'] }, 1, 0] } },
      },
    },
    { $sort: { _id: 1 } },
  ]);
  assert(floorStats.length >= 2, `Floor aggregation computed ${floorStats.length} distinct facility floors`);

  // Test 4: Reservation Creation & Time Validation
  const targetSlot = await Slot.findOne({ status: 'available' });
  const start = new Date(Date.now() + 3600 * 1000);
  const end = new Date(Date.now() + 3 * 3600 * 1000); // 2 hours

  const durationHours = Math.ceil((end - start) / 36e5);
  const testRes = await Reservation.create({
    user: driver._id,
    slot: targetSlot._id,
    vehicle_number: driver.vehicle_number,
    start_time: start,
    end_time: end,
    amount: durationHours * targetSlot.hourly_rate,
    status: 'confirmed',
  });
  assert(testRes && testRes.amount === durationHours * targetSlot.hourly_rate, `Created reservation with calculated amount ₹${testRes.amount}`);

  // Test 5: Double-Booking Conflict Prevention
  // Attempt to book the exact same slot at an overlapping time window
  const overlapStart = new Date(start.getTime() + 30 * 60000);
  const overlapEnd = new Date(end.getTime() + 30 * 60000);
  const clash = await Reservation.findOne({
    slot: targetSlot._id,
    status: { $in: ['confirmed', 'active'] },
    start_time: { $lt: overlapEnd },
    end_time: { $gt: overlapStart },
  });
  assert(clash && String(clash._id) === String(testRes._id), 'Conflict detected: overlapping time window prevented double-booking');

  // Test 6: Payment Transaction & Duplicate Protection
  const txnId = `TXN-TEST-${Date.now()}`;
  const payment = await Payment.create({
    reservation: testRes._id,
    user: driver._id,
    amount: testRes.amount,
    method: 'upi',
    status: 'paid',
    transaction_id: txnId,
  });
  assert(payment && payment.transaction_id === txnId, 'Digital payment processed with verifiable TXN ID');

  // Verify unique reservation index in Payment prevents duplicate payment
  let duplicatePrevented = false;
  try {
    await Payment.create({
      reservation: testRes._id,
      user: driver._id,
      amount: testRes.amount,
      method: 'card',
      status: 'paid',
      transaction_id: `TXN-DUP-${Date.now()}`,
    });
  } catch (dupErr) {
    duplicatePrevented = true;
  }
  assert(duplicatePrevented, 'Duplicate payment on same reservation blocked by unique constraint');

  // Test 7: Reservation Cancellation
  testRes.status = 'cancelled';
  testRes.cancellation_reason = 'Automated test suite';
  await testRes.save();
  assert(testRes.status === 'cancelled', 'Reservation successfully cancelled with audit reason');

  // Clean up test reservation and payment
  await Payment.findByIdAndDelete(payment._id);
  await Reservation.findByIdAndDelete(testRes._id);

  // Test 8: ANPR & Barrier Entry Simulation
  const freeSlot = await Slot.findOne({ status: 'available' });
  const entryNow = new Date();
  const testVehicleNumber = 'KA01TEST99';

  freeSlot.status = 'occupied';
  freeSlot.current_vehicle = testVehicleNumber;
  await freeSlot.save();

  const entryLog = await VehicleLog.create({
    vehicle_number: testVehicleNumber,
    slot: freeSlot._id,
    entry_time: entryNow,
    method: 'anpr',
    confidence_score: 99.1,
    status: 'parked',
    hourly_rate: freeSlot.hourly_rate,
  });
  assert(entryLog && entryLog.status === 'parked', 'ANPR Vehicle entry logged and barrier opened');

  // Test 9: Barrier Exit Simulation & Fee Calculation
  const exitNow = new Date(entryNow.getTime() + 90 * 60000); // 90 mins later
  const durMinutes = 90;
  const durHours = Math.ceil(durMinutes / 60);
  const exitFee = durHours * freeSlot.hourly_rate;

  entryLog.exit_time = exitNow;
  entryLog.duration_minutes = durMinutes;
  entryLog.total_fee = exitFee;
  entryLog.status = 'exited';
  await entryLog.save();

  freeSlot.status = 'available';
  freeSlot.current_vehicle = null;
  await freeSlot.save();

  assert(entryLog.status === 'exited' && entryLog.total_fee === exitFee, `Exit calculated: ${durMinutes}m parking = ₹${exitFee}, slot released`);
  await VehicleLog.findByIdAndDelete(entryLog._id);

  // Test 10: Referential Integrity on Slot Deletion
  const slotWithActiveRes = await Slot.findOne({ slot_number: 'B-03' }); // Seeded with active reservation
  const activeBooking = await Reservation.findOne({
    slot: slotWithActiveRes._id,
    status: { $in: ['confirmed', 'active'] },
  });
  assert(activeBooking != null, 'Slot deletion check: Active booking exists on B-03, deletion safely prevented');

  console.log(`\n========================================`);
  console.log(`TEST RESULTS: ${testPassed} Passed, ${testFailed} Failed`);
  console.log(`========================================\n`);
} catch (err) {
  console.error('Fatal test suite error:', err);
} finally {
  await mongoose.disconnect();
}
